#include <bits/c++config.h>

#ifdef _GLIBCPP_USE_WCHAR_T
#define C wchar_t
#include "string-inst.cc"
#endif
