// -*- C++ -*- header wrapper.

// Copyright (C) 1997-1999, 2000 Free Software Foundation, Inc.
//
// This file is part of the GNU ISO C++ Library.  This library is free
// software; you can redistribute it and/or modify it under the
// terms of the GNU General Public License as published by the
// Free Software Foundation; either version 2, or (at your option)
// any later version.

// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License along
// with this library; see the file COPYING.  If not, write to the Free
// Software Foundation, 59 Temple Place - Suite 330, Boston, MA 02111-1307,
// USA.

// As a special exception, you may use this file as part of a free software
// library without restriction.  Specifically, if other files instantiate
// templates or use macros or inline functions from this file, or you compile
// this file and link it with other files to produce an executable, this
// file does not by itself cause the resulting executable to be covered by
// the GNU General Public License.  This exception does not however
// invalidate any other reasons why the executable file might be covered by
// the GNU General Public License.


#ifndef  _INCLUDED_CPP_WCHAR_H_
# define _INCLUDED_CPP_WCHAR_H_ 1

# ifdef _IN_C_LEGACY_  /* sub-included by a C header */
      // get out of the "legacy"
    } // close extern "C"
  }   // close namespace _C_legacy::
#  undef _IN_C_LEGACY_  /* sub-included by a C header */
#  define _WCHAR_NEED_C_LEGACY_
# endif

# include <cwchar>

  // Expose global C names, including non-standard ones, but shadow
  // some names and types with the std:: C++ version.
  using std::wchar_t;
  using std::wint_t;
  using std::mbstate_t;

#if 0
  using std::fwprintf;
  using std::fwscanf;
  using std::swprintf;
  using std::swscanf;
  using std::vfwprintf;
  using std::vfwscanf;
  using std::vswprintf;
  using std::vswscanf;
  using std::vwprintf;
  using std::vwscanf;
  using std::wprintf;
  using std::wscanf;
  using std::fgetwc;
  using std::fgetws;
  using std::fputwc;
  using std::fputws;
  using std::fwide;
  using std::getwc;
  using std::getwchar;
  using std::putwc;
  using std::putwchar;
  using std::ungetwc;
#endif

  using std::wcstod;
  using std::wcstof;
  using std::wcstold;
  using std::wcstol;
  using std::wcstoll;
  using std::wcstoul;
  using std::wcstoull;
  using std::wcscpy;
  using std::wcsncpy;
  using std::wcscat;
  using std::wcsncat;

#if 0
  using std::wcsmp;
#endif

  using std::wcscoll;
  using std::wcsncmp;
  using std::wcsxfrm;
  using std::wcschr;
  using std::wcscspn;
  using std::wcslen;
  using std::wcspbrk;
  using std::wcsrchr;
  using std::wcsspn;
  using std::wcsstr;
  using std::wcstok;
  using std::wmemchr;
  using std::wmemcmp;
  using std::wmemcpy;
  using std::wmemmove;
  using std::wmemset;

#if 0
  using std::wcsftime;
#endif

  using std::btowc;
  using std::wctob;
  using std::mbsinit;
  using std::mbrlen;
  using std::mbrtowc;
  using std::wcrtomb;
  using std::mbsrtowcs;
  using std::wcsrtombs;

# ifdef _WCHAR_NEED_C_LEGACY_
  // dive back into the "swamp"
  namespace _C_legacy {
    extern "C" {
#  define _IN_C_LEGACY_
#  undef _WCHAR_NEED_C_LEGACY_
# endif /* _WCHAR_NEED_C_LEGACY_ */
#endif /* _INCLUDED_CPP_WCHAR_H_ */



