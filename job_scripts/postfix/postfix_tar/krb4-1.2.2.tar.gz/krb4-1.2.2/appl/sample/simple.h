/*
 * $Id: simple.h,v 1.3 1996/09/27 15:54:23 assar Exp $
 *
 * Copyright 1988 by the Massachusetts Institute of Technology.
 *
 * For copying and distribution information, please see the file
 * <mit-copyright.h>.
 *
 * Common definitions for the simple UDP-based Kerberos-mediated
 * server & client applications.
 */

#define SERVICE	"sample"
#define	HOST	"bach"
