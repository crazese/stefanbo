//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TelnetResource.rc
//
#define IDS_STRING1                     1
#define IDD_DIALOG1                     101
#define IDR_MENU_TELNET                 102
#define IDC_EDIT1                       1000
#define IDC_EDIT2                       1001
#define IDC_EDIT3                       1002
#define IDC_COMBO2                      1004
#define IDC_LIST1                       1005
#define ID_TELNET_SEND_AYT              40001
#define ID_CONNECTION_OPEN              40002
#define ID_CONNECTION_CLOSE             40003
#define ID_TELNET_SEND_IP               40004
#define ID_TELNET_SEND                  40007
#define ID_TELNET_SEND_AO               40008
#define ID_TELNET_SEND_EC               40009
#define ID_TELNET_SEND_EL               40010
#define ID_TELNET_SEND_BRK              40011
#define ID_SHOWVERSION                  40015
#define ID_ENCRYPT_OPTION               40017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40019
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
