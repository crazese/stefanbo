/* $Id: sysv_shadow.h,v 1.7 1999/03/13 21:15:43 assar Exp $ */

#include <shadow.h>

int sysv_expire(struct spwd *);
