char *krb4_long_version = "krb4-0.9.7 on Windows NT";
char *krb4_version = "0.9.7";
