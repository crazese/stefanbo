#!/bin/sh
# queue_stat.sh - a small script to report queue stat

# output the number of messages in the incoming, active, and deferred
# queues of postfix one per line suitable for use with snmpd/cricket
#
# mailqsize was originally written by Vivek Khera.  All I did was
# make it update an rrd.
# 2003/01/24 01:19:37  Mike Saunders <method at method DOT cx>
# 		       I bundled this with a modified mailgraph
# 2003/04/14           Ralf Hildebrandz <ralf.hildebrandt at charite DOT de>
#
# 2006/04/24 13:09:43  He zhiqiang <hzqbbc@hzqbbc.com>
# 		       Integrate queuegraph and mailgraph into my ExtMan

# Change this to the location where your RRD is stored:
PATH=/usr/local/rrdtool/bin:/usr/local/bin:/usr/local/sbin:/sbin:/bin:/usr/bin:/usr/sbin:
export PATH=$PATH

qdir=`postconf -h queue_directory`
active=`find $qdir/active -type f -print | wc -l | awk '{print $1}'`
deferred=`find $qdir/deferred -type f -print | wc -l | awk '{print $1}'`
incoming=`find $qdir/incoming -type f -print | wc -l | awk '{print $1}'`
maildrop=`find $qdir/maildrop -type f -print | wc -l | awk '{print $1}'`
hold=`find $qdir/hold -type f -print | wc -l |awk '{print $1}'`

printf "$incoming\n$maildrop\n$active\n$deferred\n$hold\n";

rrdtool update /var/lib/mailgraph_queue.rrd \
	"N:$incoming:$maildrop:$active:$deferred:$hold"
