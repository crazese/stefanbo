#!/bin/sh
# queue_mkrrd.sh - script to create queue rrd file
#
# Original written by Ralf Hildebrandz <ralf.hildebrandt@charite.de>
# 
# Rewritten by: He zhiqiang <hzqbbc@hzqbbc.com>

PATH=/usr/local/rrdtool/bin:/usr/local/bin:/usr/local/sbin:/sbin:/bin:/usr/bin:/usr/sbin:
export PATH=$PATH

rrdtool create /var/lib/mailgraph_queue.rrd --step 60 \
	DS:incoming:ABSOLUTE:900:0:U \
	DS:maildrop:ABSOLUTE:900:0:U \
	DS:active:ABSOLUTE:900:0:U \
	DS:deferred:ABSOLUTE:900:0:U \
	DS:hold:ABSOLUTE:900:0:U \
	RRA:AVERAGE:0.5:1:20160 \
	RRA:AVERAGE:0.5:30:2016 \
	RRA:AVERAGE:0.5:60:105120 \
	RRA:MAX:0.5:1:1440 \
	RRA:MAX:0.5:30:2016 \
	RRA:MAX:0.5:60:105120
