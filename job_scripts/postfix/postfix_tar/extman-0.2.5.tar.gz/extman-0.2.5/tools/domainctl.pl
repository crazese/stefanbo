#!/bin/sh
exec ${PERL-perl} -Swx $0 ${1+"$@"}

#!/usr/bin/perl -w
# vim: set ci et ts=4 sw=4:
#   userinfo.pl: domain name management
#	     Author: chifeng <chifeng At gmail.com>
#	       Date: 2007-11-28 15:39:00
#   Last Update: 2008-02-02 22:31:08 by hzqbbc
#      Homepage: http://www.extmail.org
#	Version: 0.2
#
#
use vars qw($DIR);

BEGIN {
    my $path = $0;
    if ($path =~ s/tools\/[0-9a-zA-Z\-\_]+\.pl$//) {
	if ($path !~ /^\//) {
	    $DIR = "./$path";
	} else {
            $DIR = $path;
        }
    } else {
        $DIR = '../';
    }
    unshift @INC, $DIR .'libs';
};

# use strict; # developing env
no warnings; # production environment
use POSIX qw(strftime);
use Ext::Mgr;
use CmdTools;
use Ext::DateTime qw(time2epoch epoch2time);
#use Ext::MgrApp qw(gen_domain_hashdir);
use Getopt::Long;
use Switch;
use IO::File;
use Data::Dumper;
require $DIR.'/tools/setid.pl';

my %opt = (); # parameters
my @exp; # export parameters
my $ctx = CmdTools->new( config => $DIR . '/webman.cf', directory => $DIR );
my $c = \%Ext::Cfg;
my $mgr = $ctx->ctx; # backend object
my $set_user=$c->{SYS_DEFAULT_UID};
my $set_group=$c->{SYS_DEFAULT_GID};

Getopt::Long::Configure('no_ignore_case');
Getopt::Long::GetOptions(\%opt,
    'mode|m=s',
    'domainname|d=s',
    'description=s',
    'maxuser=i',
    'maxalias=i',
    'maxquota=i',
    'maxndquota=i',
    'expire|e=s',
    'active|a=i',
    'signup|s=i',
    'transport=s',
    'accountquota=i',
    'accountndquota=i',
    'accountlifetime=s',
    'accountservices=s',
    'setgid=s',
    'setuid=s',
    'quiet|qq',
) or exit 1;

sub output {
    my $type = $_[0];
    print "\n";
    for $href (@exp){
        foreach my $i ( keys %$href ){
            if( !$opt{mode} or $opt{help}){
                printf ("--%s = ", $i);
            }else{
                printf ("%s = ", $i);
            }
            printf ("%s", $href->{$i}),;
            print "\n";
        }
    }
    exit;
}

sub usage {
    push @exp, { mode => "add,del,list,show,mod,help",
        domainname => "domain.tld",
        description => "A test domain",
        maxuser => 100,
        maxalias => 100,
        maxquota => 5,
        maxndquota => 5,
        expire => "2008-08-18",
        active => "1 or 0",
        signup => "1 or 0",
        transport => "mx1.extmail.org",
        accountquota => 100,
        accountndquota => 100,
        accountlifetime => "1y",
        accountservices => "smtp,smtpd,pop3,imap,webmail,netdisk",
        setgid => "vgroup",
        setuid => "vuser",
        quiet => "1 or 0"
    };
    output;
    exit 1;
}
if($opt{setgid} && $opt{setuid}){
    $set_user = $opt{setuid};
    $set_group = $opt{setgid};
}
set_gid($set_user);
set_uid($set_group);

sub add {
    if( !$opt{domainname} ){
        push @exp, { error => "Please input a domain name to add!" };
        output ;
    }
    my $domainname = $opt{domainname};
    my $description = $opt{domainname};
    if( defined $opt{description} ){
	$description = $opt{description};
    }
    my $hashdirpath = "NULL";
    my $maxuser = $c->{SYS_DEFAULT_MAXUSERS};
    if(defined $opt{maxuser}){
	$maxuser = $opt{maxuser};
    }
    my $maxalias = $c->{SYS_DEFAULT_MAXALIAS};
    if(defined $opt{maxalias}){
	$maxalias = $opt{maxalias};
    }
    #maxquota,maxndquota,default_quota,default_ndquota
    my $maxquota = defined $opt{maxquota} ? $opt{maxquota} : $c->{SYS_DEFAULT_MAXQUOTA};
    $maxquota = $maxquota * 1024 * 1024;
    $maxquota = $maxquota."S";

    my $maxndquota = defined $opt{maxndquota} ? $opt{maxndquota} : $c->{SYS_DEFAULT_MAXNDQUOTA};
    $maxndquota = $maxndquota * 1024 * 1024;
    $maxndquota = $maxndquota."S";
    my $transport = "NULL";
    if(defined $opt{transport}){
	$transport = $opt{transport};
    }
    my $can_signup = 0;
    if(defined $opt{signup}){
	$can_signup = $opt{signup};
    }
    my $default_quota = defined $opt{accountquota} ? $opt{accountquota} : $c->{SYS_USER_DEFAULT_QUOTA};
    $default_quota = $default_quota * 1024 * 1024;
    $default_quota = $default_quota."S";

    my $default_ndquota = defined $opt{accountndquota} ? $opt{accountndquota} : $c->{SYS_USER_DEFAULT_NDQUOTA};
    $default_ndquota = $default_ndquota * 1024 * 1024;
    $default_ndquota = $default_ndquota."S";

    my $default_expire = defined $opt{accountlifetime} ? $opt{accountlifetime} : $c->{SYS_USER_DEFAULT_EXPIRE};

    my $createdate = strftime("%Y-%m-%d %H:%M:%S", localtime);
    my $expiredate = '0000-00-00'; # set to unlimited/auto
    my $service = defined $opt{accountservices} ? $opt{accountservices} : $c->{SYS_DEFAULT_SERVICES};

    my %services= (
	    pwdchange=>0,
	    smtpd=>1,
	    smtp=>1,
	    webmail=>1,
	    netdisk=>1,
	    imap=>1,
	    pop3=>1
	);
    my @sv = split(/,/,$service);
    foreach (@sv) {
	    if (exists $services{$_}){
	        $services{$_}=0;
	    }
    }
    my $active = defined $opt{active} ? $opt{active} : 0;

    if($mgr->get_domain_info($domainname)){
        push @exp, { error => "domain no exist!" };
        output ;
    }else{
        push @exp, { domain => $domainname,
            description => $description,
            expiredate => $expiredate,
            maxalias => $maxalias,
            maxusers => $maxuser,
            maxquota => $maxquota,
            maxndquota => $maxndquota,
            transport => $transport,
            signup => $can_signup,
            defaultquota => $default_quota,
            defaultndquota => $default_ndquota,
            defaultexpire => $default_expire,
            disablesmtpd => $services{smtpd},
            disablesmtp => $services{smtp},
            disablewebmail => $services{webmail},
            disablenetdisk => $services{netdisk},
            disableimap => $services{imap},
            disablepop3 => $services{pop3},
            active => $active,
            status => 1
        };
        my $rc = $mgr->add_domain(
            domain => $domainname,
            description => $description,
            hashdirpath => $hashdirpath,
            maxusers => $maxuser,
            maxalias => $maxalias,
            maxquota => $maxquota,
            maxndquota => $maxndquota,
            transport => $transport,
    	    can_signup => $can_signup,
            default_quota => $default_quota,
            default_ndquota => $default_ndquota,
            default_expire => $default_expire,
            disablesmtpd => $services{smtpd},
            disablesmtp => $services{smtp},
            disablewebmail => $services{webmail},
            disablenetdisk => $services{netdisk},
            disablepop3 => $services{pop3},
            disableimap => $services{imap},
            expire => $expiredate,
            create => $createdate,
            active => $active,
        );
        output ;
    }
}

sub del {
    if($opt{domainname}){
        if($mgr->get_domain_info($opt{domainname})){
            if(!($mgr->delete_domain($opt{domainname}))){
                push @exp, { email => $opt{domainname}, status => 1};
                output ;
            }else{
                push @exp, { email => $opt{domainname}, status => 0};
                output ;
            }
        }else{
            push @exp, { error => "Username no exist!"};
            output ;
        }
    }else{
        push @exp, { error => "Please input a domainname to delete!" };
        output ;
    }
}

sub list {
    my $all = $mgr->get_domains_list || [];
    for(my $i=0; $i<scalar @$all; $i++) {          
        my $e = $all->[$i];
        push @exp, {domain => $e->{domain}, 
            createdate => $e->{create}, 
            expiredate => $e->{expire}, 
            signup => $e->{can_signup},
            active => $e->{active}
        };
    }
    output ;
}

sub show {
    if(!$opt{domainname}){
        push @exp, { error => "Please input a domain name" };
        output ;
    }

    if(my $minfo = $mgr->get_domain_info($opt{domainname})){
        push @exp, { domain => $minfo->{domain},
            description => $minfo->{description},
            createdate => $minfo->{create},
            expiredate => $minfo->{expire},
            hashdirpath => $minfo->{hashdirpath},
            maxalias => $minfo->{maxalias},
            maxusers => $minfo->{maxusers},
            maxquota => $minfo->{maxquota},
            maxndquota => $minfo->{maxndquota},
            transport => $minfo->{transport},
            signup => $minfo->{can_signup},
            defaultquota => $minfo->{default_quota},
            defaultndquota => $minfo->{default_ndquota},
            defaultexpire => $minfo->{default_expire},
            disablesmtpd => $minfo->{disablesmtpd},
            disablesmtp => $minfo->{disablesmtp},
            disablewebmail => $minfo->{disablewebmail},
            disablenetdisk => $minfo->{disablenetdisk},
            disableimap => $minfo->{disableimap},
            disablepop3 => $minfo->{disablepop3},
            active => $minfo->{active}
        };
        output ;
    }else{
        push @exp, { error => "Domain no exists!" };
        output ;
    }
}

sub mod {
    if(!$opt{domainname}){
        push @exp, { error => "Please input a domain name!" };
        output ;
    }
    my $domainname = $opt{domainname};
    my $ul = $mgr->get_domain_info($domainname);
    if(!($ul)){
        push @exp, { error => "domain no exist!" };
        output ;
    }
    my $description = defined $opt{description} ? $opt{description} : $ul->{description};
    my $maxuser = defined $opt{maxuser} ? $opt{maxuser} : $ul->{maxusers};
    my $maxalias = defined $opt{maxalias} ? $opt{maxalias} : $ul->{maxalias};
    my $maxquota = $ul->{maxquota};
    if(defined $opt{maxquota}){
        $maxquota = $opt{maxquota}*1024*1024;
        $maxquota = $maxquota."S";
    }
    my $maxndquota = $ul->{maxndquota};
    if(defined $opt{maxndquota}){
        $maxndquota = $opt{maxndquota}*1024*1024;
        $maxndquota = $maxndquota."S";
    }
    my $transport = $opt{transport} ? $opt{transport} : $ul->{transport};
    my $can_signup = defined $opt{signup} ? $opt{signup} : $ul->{can_signup};
    my $default_quota = defined $opt{accountquota} ? $opt{accountquota} : $ul->{default_quota};
    my $default_ndquota = defined $opt{accountndquota} ? $opt{accountndquota} : $ul->{default_ndquota};
    my $default_expire = defined $opt{accountlifetime} ? $opt{accountlifetime} : $ul->{default_expire};
    my $expiredate = $opt{expire} ? $opt{expire} : $ul->{expire};
    my %services = (
        'pwdchange' => 1,
        'smtpd' => 1,
        'smtp' => 1,
        'webmail' => 1,
        'netdisk' => 1,
        'pop3' => 1,
        'imap' => 1,
    );
    #enable services,
    if ($opt{accountservices}) {
        my @sve = split(/,/,$opt{accountservices});
        foreach(@sve){
            if (exists $services{$_}){
                $services{$_} = 0;
            }
        }
    }
    my $active = defined $opt{active} ? $opt{active} : $ul->{active};
    push @exp, { domain => $domainname,
        description => $description,
        expiredate => $expiredate,
        maxalias => $maxalias,
        maxuser => $maxuser,
        maxquota => $maxquota,
        maxndquota => $maxndquota,
        transport => $transport,
        Signup => $can_signup,
        defaultquota => $default_quota,
        defaultndquota => $default_ndquota,
        defaultexpire => $default_expire,
        disablesmtpd => $services{smtpd},
        disablesmtp => $services{smtp},
        disablewebmail => $services{webmail},
        disablenetdisk => $services{netdisk},
        disableimap => $services{imap},
        disablepop3 => $services{pop3},
        active => $active,
    };
    my $rc = $mgr->modify_domain(
        domain => $domainname,
        description => $description,
        maxusers => $maxuser,
        maxalias => $maxalias,
        maxquota => $maxquota,
        maxndquota => $maxndquota,
        transport => $transport,
        can_signup => $can_signup,
        default_quota => $default_quota,
        default_ndquota => $default_ndquota,
        default_expire => $default_expire,
        disablesmtpd => $services{smtpd},
        disablesmtp => $services{smtp},
        disablewebmail => $services{webmail},
        disablenetdisk => $services{netdisk},
        disablepop3 => $services{pop3},
        disableimap => $services{imap},
        expire => $expiredate,
        active => $active,
    );
    output ;
}

if($opt{mode}){
    switch ($opt{mode}){
        case "add" { add(); }
        case "del" { del(); }
        case "list" { list(); }
        case "show" { show(); }
        case "mod" { mod(); }
        case "help" { usage(); }
        else { usage(); }
    }
}else{
    usage ();
}

