#!/bin/sh
exec ${PERL-perl} -Swx $0 ${1+"$@"}

#!/usr/bin/perl -w
#   userinfo.pl: admin user management
#	 Author: chifeng <chifeng At gmail.com>
#	   Date: 2007-11-28 15:39:00
#      Homepage: http://www.extmail.org
#	Version: 0.2
#
#
use vars qw($DIR);

BEGIN {
    my $path = $0;
    if ($path =~ s/tools\/[0-9a-zA-Z\-\_]+\.pl$//) {
	if ($path !~ /^\//) {
	    $DIR = "./$path";
	} else {
            $DIR = $path;
        }
    } else {
        $DIR = '../';
    }
    unshift @INC, $DIR .'libs';
};

# use strict; # developing env
no warnings; # production environment
use POSIX qw(strftime);
use Ext::Mgr;
use Ext::Utils qw(untaint);
use CmdTools;
use Ext::DateTime qw(time2epoch epoch2time);
use Getopt::Long;
use Switch;
use IO::File;
require $DIR.'/tools/setid.pl';

my $ctx = CmdTools->new( config => $DIR . '/webman.cf', directory => $DIR );
my $c = \%Ext::Cfg;
my $mgr = $ctx->ctx; # backend object
my $basedir = $c->{SYS_MAILDIR_BASE};
my %opt = ();
my @exp; # export parameters
my $set_user=$c->{SYS_DEFAULT_UID};
my $set_group=$c->{SYS_DEFAULT_GID};

Getopt::Long::Configure('no_ignore_case');
Getopt::Long::GetOptions(\%opt,
	'mode=s',
	'file|f=s',
	'managername=s',
	'password|p=s',
	'changepwd|c=i',
	'name|n=s',
	'active=i',
	'expire|e=s',
	'question|q=s',
	'answer=s',
	'adddomains=s',
	'deldomains=s',
	'domains=s',
	'setgid=s',
	'setuid=s',
	'quiet|qq',
) or exit 1;

sub output {
    my $type = $_[0];
    print "\n";
    for $href (@exp){
        foreach my $i ( keys %$href ){
            if( !$opt{mode} or $opt{help}){
                printf ("--%s = ", $i);
            }else{
                printf ("%s = ", $i);
            }
            printf ("%s", $href->{$i}),;
            print "\n";
        }
    }
    exit;
}

sub usage {
    push @exp, { mode => "add,badd,del,bdel,list,show,mod,help",
        file => "/path/to/filename.csv",
        managername => "managername",
        password => "******",
        changepwd => "1 or 0",
        name => "name",
        active => "1 or 0",
        expire => "2010-08-18",
        question => "what are you doing?",
        answer => "working",
        adddomains => "domain1.tld,domain2.tld,...",
        deldomains => "domain1.tld,domain2.tld,...",
        domains => "domain1.tld,domain2.tld,...",
        setgid => "vgroup",
        setuid => "vuser",
        quiet => "1 or 0"
    };
    output ;
}
if($opt{setgid} && $opt{setuid}){
    $set_user = $opt{setuid};
    $set_group = $opt{setgid};
}
set_gid($set_user);
set_uid($set_group);

sub adduser {
    my $username = $_[0];
    my $uid = $_[1];
    my $password = $_[2];
    my $domains = $_[3];

    if($mgr->get_manager_info($username)){
        push @exp, { error => "user exist!" };
        output ;
    }else{
        my @dms = split(/,/,$domains);
        foreach my $d (@dms){
            if(!($mgr->get_domain_info($d))){
                push @exp, { error => "$d domain noexist!" };
                output ;
            }
        }
        my $createdate = strftime("%Y-%m-%d %H:%M:%S", localtime);
        my $expiredate = '0000-00-00'; # default to unlimited/auto

        $domains =~ s#,# #g;
        my $rc = $mgr->add_manager(
            manager => $username,
            cn => $uid,
            expire => $expiredate,
            create => strftime("%Y-%m-%d %H:%M:%S", localtime),
            active => $opt{active} ? $opt{active} : 0,
            domain => $domains,
            question => $opt{question} ? $opt{question} : '',
            answer => $opt{answer} ? $opt{answer} : '',
            disablepwdchange => $opt{changepwd} ? $opt{changepwd} : 0,
            type => 'postmaster',
            passwd => $password,
        );
        if($rc){
            return 0;
        }else{
            return 1;
        }
    }
}

sub add {
    if(!($opt{managername} && $opt{password} && $opt{domains})){
        push @exp, { error => "Parameter Error!" };
        output ;
    }else{
        my $username = $opt{managername};
        my $uid = $opt{managername};
        if($opt{name}){
            $uid = $opt{name};
        }
        my $password = $opt{password};
        my $domains = $opt{domains};
        my $rv = adduser $username,$uid,$password,$domains ;
        if ($rv == 1){
            push @exp, { adminname => $username,
                password => $password,
                type => postmaster,
                domains => $domains,
                status => 1
            };
            output ;
        }else{
            push @exp, { error => "$username add faild!", status => 0 };
            output ;
        }
    }
}

sub badd {
    if($opt{file}){
        if( -e $opt{file} ){
            my @info;
            my @rv;
            open(BAF, "< $opt{file}")
                or die "Can't open $opt{file} !\n";
            while(<BAF>){
                chomp;
                @info = split(/ /, untaint($_));
                my $rv = adduser $info[0],$info[0],$info[1],$info[2];
                if($rv == 1){
                    push @exp, { admin => "$info[0]", status => 1 };
                    output ;
                }else{
                    push @exp, { admin => "$info[0]", status => 0 };
                    output ;
                }
            }
            close BAF;
        }else{
            push @exp, { error => "$opt{file} file no exist!" };
            output ;
        }
    }else{
        push @exp, { error => "Please input a text file" };
        output ;
    }
}

sub deluser {
    my $username = $_[0];
    if($mgr->get_manager_info($username)){
        if(!($mgr->delete_manager($username))){
            push @exp, { admin => "$username", status => 1 };
            output ;
        }else{
            push @exp, { admin => "$username", status => 0 };
            output ;
        }
    }else{
        push @exp, { error => "$username no exist!" };
        output ;
    }
}

sub del {
    if($opt{managername}){
        deluser $opt{managername};
    }else{
        push @exp, { error => "Please input a admin name to delete!" };
        output ;
    }
}

sub bdel {
    if($opt{file}){
        if( -e $opt{file} ){
            open(BDF, "< $opt{file}")
                or die "Can't open $opt{file} !\n";
            while(<BDF>){
                chomp $_;
                deluser $_;
            }
            close BDF;
        }else{
            push @exp, { error => "$opt{file} file no exist!" };
            output ;
        }
    }else{
        push @exp, { error => "Please input a text file!" };
        output ;
    }
}


sub list {
    my $all = $mgr->get_managers_list || [];
    for(my $i=0; $i<scalar @$all; $i++) {          
        my $e = $all->[$i];
        push @exp, { managername => $e->{manager},
            name => $e->{cn},
            type => $e->{type},
            expire => $e->{expire},
            active => $e->{active}
        };
    }
    output ;
}

sub show {
    my $dms = [];
    if($opt{managername}){
        if(my $minfo = $mgr->get_manager_info($opt{managername})){
            if($minfo->{type} eq 'admin'){
                push @$dms,'ALL Domains';
            }else{
                $dms = $minfo->{domain};
            }
            my $d;
            foreach my $rv (@$dms){
                $d = $d."$rv ";
            }
            push @exp, { type => $minfo->{type},
                managername => $minfo->{manager},
                name => $minfo->{cn},
                active => $minfo->{active},
                disablepwdchange => $minfo->{disablepwdchange},
                question => $minfo->{question},
                answer => $minfo->{answer},
                createdate => $minfo->{create},
                expiredate => $minfo->{expire},
                domains => $d,
            };
            output ;
        }else{
            push @exp, { error => "$opt{managername} no exist!" };
            output ;
        }
    }else{
        push @exp, { error => "Please input a admin name to show!" };
        output ;
    }
}

sub mod {
    if(!($opt{managername})){
        push @exp, { error => "Please input a manager name!" };
        output ;
    }
    my $manager = $opt{managername};
    my $rv = $mgr->get_manager_info($manager);
    if(!$rv) {
        push @exp, { error => "$manager no exist!" };
        output ;
    }
    my $name = $opt{name} ? $opt{name} : $rv->{cn};
    my $changepwd = defined $opt{changepwd} ? $opt{changepwd} : $rv->{disablepwdchange};
    my $active = defined $opt{active} ? $opt{active} : $rv->{active};
    my @ttime = split(/ /,$rv->{expire});
    my $time = $ttime[1];
    my $expire = defined $opt{expire} ? $opt{expire}." ".$time : $rv->{expire};
    my $question = defined $opt{question} ? $opt{question} : $rv->{question};
    my $answer = defined $opt{answer} ? $opt{answer} : $rv->{answer};
    my $password = defined $opt{password} ? $opt{password} : undef;
    my $alldomains = $rv->{domain};
    if($opt{adddomains}){
        my @idomains = split(/,/,$opt{adddomains});
        foreach my $idm (@idomains){
            if(!$mgr->get_domain_info($idm)){
                push @exp, { error => "$idm domain no exist!" };
                output ;
            }
        }
        push @$alldomains,@idomains;
    }
    if($opt{deldomains}){
        my @rdomains = split(/,/,$opt{deldomains});
        my $i = 0;
        foreach my $domain (@rdomains){
            for (;$i < scalar @$alldomains ; $i++){
                last if (@$alldomains[$i] eq $domain);
            }
            splice(@$alldomains,$i,1);
            $i=0;
        }
    }
    if($opt{domains}){
        my @setdomains = split(/,/,$opt{domains});
        foreach my $setdm (@setdomains){
            if(!$mgr->get_domain_info($setdm)){
                push @exp, { error => "$setdm domain no exist!" };
                output ;
            }
        }
        @$alldomains = @setdomains ;
    }
    my %hash = ();
    my @alldomains2;
    foreach my $member (@$alldomains){
        $hash{$member} = 1;
    }
    foreach (keys %hash){
        push (@alldomains2,$_);
    }
    my $adomains = join(" ",@alldomains2);
    push @exp, { manager => $manager,
        name => $name,
        expire => $expire,
        changepwd => $changepwd,
        active => $active,
        question => $question,
        answer => $answer,
        domains => $adomains,
        status => 1,
    };
    push @exp, { password => $password, } if($password);
    $mgr->modify_manager(
        manager => $manager,
        cn => $name,
        expire => $expire,
        active => $active,
        domain => $adomains,
        question => $question,
        answer => $answer,
        disablepwdchange => $changepwd,
        passwd => $password,
    );
    output ;
}

if($opt{mode}){
    switch ($opt{mode}){
        case "add" { add(); }
        case "badd" { badd(); }
        case "del" { del(); }
        case "bdel" { bdel(); }
        case "list" { list(); }
        case "show" { show(); }
        case "mod" { mod(); }
        case "help" { usage(); }
        else { usage(); }
    }
}else{
    usage ();
}

