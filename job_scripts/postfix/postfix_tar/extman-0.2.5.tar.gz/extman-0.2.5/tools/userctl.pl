#!/bin/sh
exec ${PERL-perl} -Swx $0 ${1+"$@"}

#!/usr/bin/perl -w
# vim: set ci et ts=4 sw=4:
#   userinfo.pl: user managerment
#	     Author: chifeng <chifeng At gmail.com>
#	       Date: 2008-01-02 17:49:00
#   Last update: 2008-02-01 08:15:00 by hzqbbc
#      Homepage: http://www.extmail.org
#	    Version: 0.4
#
#
use vars qw($DIR);

BEGIN {
    my $path = $0;
    if ($path =~ s/tools\/[0-9a-zA-Z\-\_]+\.pl$//) {
	if ($path !~ /^\//) {
	    $DIR = "./$path";
	} else {
            $DIR = $path;
        }
    } else {
        $DIR = '../';
    }
    unshift @INC, $DIR .'libs';
};

# use strict; # developing env
no warnings; # production environment
use POSIX qw(strftime);
use Ext::Mgr;
use Ext::Utils qw(untaint);
use CmdTools;
use Ext::DateTime qw(time2epoch epoch2time);
use Getopt::Long;
use Switch;
use IO::File;
require $DIR.'/tools/setid.pl';

my %opt = (); # parameters
my @exp; # export parameters
my $ctx = CmdTools->new( config => $DIR . '/webman.cf', directory => $DIR );
my $c = \%Ext::Cfg;
my $mgr = $ctx->ctx; # backend object
my $basedir = $c->{SYS_MAILDIR_BASE};
my $dir = $c->{SYS_CONFIG};
my $set_user=$c->{SYS_DEFAULT_UID};
my $set_group=$c->{SYS_DEFAULT_GID};

Getopt::Long::Configure('no_ignore_case');
Getopt::Long::GetOptions(\%opt,
    'mode|m=s',
    'file|f=s',
    'username|u=s',
    'domain|d=s',
    'password|p=s',
    'name=s',
    'question=s',
    'answer=s',
    'gid=i',
    'uid=i',
    'expire|e=s',
    'quota|q=s',
    'ndquota=s',
    'active|a=i',
    'services=s',
    'setgid=s',
    'setuid=s',
    'delmaildir=s',
    'help|h',
    'quiet|qq',
) or exit 1;

if($opt{setgid} && $opt{setuid}){
    $set_user = $opt{setuid};
    $set_group = $opt{setgid};
}
set_gid($set_user);
set_uid($set_group);

# Using: output 
# output function will print %exp hash variable
#
sub output {
    my $type = $_[0];
    print "\n";
    for $href (@exp){
        foreach my $i ( keys %$href ){
            if( !$opt{mode} or $opt{help}){
                printf ("--%s = ", $i);
            }else{
                printf ("%s = ", $i);
            }
            printf ("%s", $href->{$i}),;
            print "\n";
        }
    }
    exit;
}

sub usage {
    push @exp, { mode => "add,badd,del,bdel,list,show,mod,help",
        file => "/path/to/filename.csv",
        username => "username@domain.tld",
        domain => "domain.tld",
        name => "name",
        question => "what are you doing?",
        answer => "working",
        gid => "gid",
        uid => "uid",
        expire => "2009-09-17",
        quota => 100,
        ndquota => 100,
        active => "1 or 0",
        services => "smtp,smtpd,pop3,imap,webmail,netdisk,pwdchange",
        setgid => "vgroup",
        setuid => "vuser",
        delmaildir => "1 or 0",
        quiet => "1 or 0"
    };
    output ;
}

sub adduser {
    my $email = $_[0];
    my $password = $_[1];
    my $quota = $_[2]; # MB
    my $netdiskquota = $_[3]; # MB
    my ($user,$domain) = split(/@/,$email);
    my $uid = $c->{SYS_DEFAULT_UID};
    my $gid = $c->{SYS_DEFAULT_GID};

    my $createdate = strftime("%Y-%m-%d %H:%M:%S", localtime);
    my $expiredate = '0000-00-00'; # default to unlimited/auto
    my $question = defined $opt{question} ? $opt{question} : "";
    my $answer = defined $opt{answer} ? $opt{answer} : "";
    my $name = defined $opt{name} ? $opt{name} : $user;

    my $path = $domain."/".$user;
    $netdiskquota ||= $c->{SYS_USER_DEFAULT_NDQUOTA};
    $netdiskquota = num2quota($netdiskquota);

    $quota ||= $c->{SYS_USER_DEFAULT_QUOTA};
    $quota = num2quota($quota);

    my $service = $c->{SYS_DEFAULT_SERVICES};
    my %disable= (
        pwdchange=>0,
        smtpd=>1,
        smtp=>1,
        webmail=>1,
        netdisk=>1,
        imap=>1,
        pop3=>1
    );
    my @sv = split(/,/,$service);
    foreach (@sv) {
        if (exists $disable{$_}){
            $disable{$_}=0;
        }
    }
    my $createdate = strftime("%Y-%m-%d %H:%M:%S", localtime),
    my $ul = $mgr->get_user_info($email);
    my $ula = $mgr->get_alias_info($email);
    if($ul || $ula){
        push @exp, { error => "User exists!" };
        output ;
    }else{
        my $rv = $mgr->add_user(
        mail => "$user\@$domain",
        domain => $domain,
        uid => $user,
        cn => $name,
        uidnumber => $uid,
        gidnumber => $gid,
        create => $createdate,
        expire => $expiredate,
        passwd => $password,
        quota => $quota,
        question => $question,
        answer => $answer,
        mailhost => "",
        maildir => "$path/Maildir/",
        homedir => $path,
        netdiskquota => $netdiskquota,
        active => 1,
        disablepwdchange => $disable{pwdchange},
        disablesmtpd => $disable{smtpd},
        disablesmtp => $disable{smtp},
        disablewebmail => $disable{webmail},
        disablenetdisk => $disable{netdisk},
        disablepop3 => $disable{pop3},
        disableimap => $disable{imap}
        );
        system("$dir/tools/maildirmake.pl $basedir/$path/Maildir/");
        if($rv){
            return 0;
        }else{
            push @exp, { email => $email,
                    commonname => $name,
                    password => $password,
                    uidnumber => $uid,
                    gidnumber => $gid,
                    quota => $quota,
                    question => $question,
                    answer => $answer,
                    netdiskquota => $netdiskquota,
                    active => $active,
                    maildir => "$path\/Maildir/",
                    homedir => $path,
                    routing => "",
                    createdate => $createdate,
                    expiredate => $expiredate,
                    disablepwdchange => $disable{pwdchange},
                    disablesmtpd => $disable{smtpd},
                    disablesmtp => $disable{smtp},
                    disablewebmail => $disable{webmail},
                    disablenetdisk => $disable{netdisk},
                    disablepop3 => $disable{pop3},
                    disableimap => $disable{imap},
                    status => 1
            };
            return 1;
        }
    }
}

sub add {
    if($opt{username}){
	    my $email = $opt{username};
	    my $password = $opt{password};
	    my $quota = $c->{SYS_USER_DEFAULT_QUOTA}; #default size got from webman.cf

        if ($opt{quota}) {
            $quota = $opt{quota};
        }

        if(!($password)) {
            push @exp, { error => "Password can not Empty!" };
            output ;
        }

        if(! (adduser $email,$password,$quota)){
            push @exp, { error => "Add username faild!" , status => 0 };
        }
    }else{
        push @exp, { error => "Please input username and some infomation for add!"};
    }
    output ;
}

sub badd {
    if(!$opt{file}){
        push @exp, { error => "Please input a text file!" };
        output ;
    }
	if( -e $opt{file} ){
        my @info;
        my $rv;
        open(BAF,"< $opt{file}")
            or die "Can't open $opt{file} !\n";
        while(<BAF>){
            chomp;
            @info = split(/ /, untaint($_));
            $rv = adduser $info[0],$info[1],$info[2];
        }
        close BAF;
    }else{
        push @exp, { error => "File no exist!" };
    }
    output ;
}

sub deluser {
    my $username = $_[0];
    my $delmaildir = 0;
    if(defined $opt{delmaildir} and ($opt{delmaildir} != 0)){
        $delmaildir = 1;
    }else{
        $delmaildir = 0;
    }
    if(my $rv = $mgr->get_user_info($username)){
        if($mgr->delete_user($username)){
            push @exp, { email => $username, status => 0 };
        }else{
            push @exp, { email => $username, status => 1 };
            if($delmaildir != 0){
                system("/bin/rm -fr \"$c->{SYS_MAILDIR_BASE}/$rv->{homedir}\"");
            }
        }
    }else{
        push @exp, { error => "Username no exist!" };
    }
}

sub del {
    if($opt{username}){
	    deluser $opt{username};
    }else{
        push @exp, { error => "Please input a email address to delete!" };
    }
    output ;
}

sub bdel {
    if(!$opt{file}){
        push @exp, { error => "Please input a text file!" };
        output ;
    }
    if( -e $opt{file} ){
        open(BDF, "< $opt{file}")
            or die "Can't open $opt{file} !\n";
        while(<BDF>){
            chomp $_;
            deluser untaint($_);
        }
        close BDF;
    }else{
        push @exp, { error => "File no exist!" };
    }
    output ;
}

sub list {
    if(!$opt{domain}){
        push @exp, { error => "Please input a domain name!" };
        output ;
    }
    my $domain = $opt{domain};
    if(!($mgr->get_domain_info($domain))){
        push @exp, { error => "domain no exists!" };
        output ;
    }
    my $ul = $mgr->get_users_list($domain);
    foreach my $u (@$ul) {
        push @exp, { email => $u->{mail}, cn => $u->{cn}, expire => $u->{expire}, active => $u->{active} };
    }
    output ;
}

sub show {
    my $dms = [];
    if(!$opt{username}) {
        push @exp, { error => "Please input a username to show!" };
        output ;
    }

    if( my $ul = $mgr->get_user_info($opt{username})){
        push @exp, { type => "user",
                    email => $ul->{mail},
                    commonname => $ul->{cn},
                    password => $ul->{passwd},
                    uidnumber => $ul->{uidnumber},
                    gidnumber => $ul->{gidnumber},
                    quota => $ul->{quota},
                    question => $ul->{question},
                    answer => $ul->{answer},
                    netdiskquota => $ul->{netdiskquota},
                    active => $ul->{active},
                    maildir => "$basedir\/$ul->{maildir}",
                    homedir => "$basedir\/$ul->{homedir}",
                    routing => $ul->{mailhost},
                    createdate => $ul->{create},
                    expiredate => $ul->{expire},
                    disablepwdchange => $ul->{disablepwdchange},
                    disablesmtpd => $ul->{disablesmtpd},
                    disablesmtp => $ul->{disablesmtp},
                    disablewebmail => $ul->{disablewebmail},
                    disablenetdisk => $ul->{disablenetdisk},
                    disablepop3 => $ul->{disablepop3},
                    disableimap => $ul->{disableimap}
        };
        output ;
    }else{
        push @exp, { error => "Username no exist!" };
        output ;
    }
}

sub num2quota {
    # sys_quota_type, valid type: vda|courier
    #SYS_QUOTA_TYPE = courier
    my $quota = $_[0]; # must be number
    $quota = $quota * 1024 * 1024;
    my $type = $c->{SYS_QUOTA_TYPE} || 'vda';
    if ($type eq 'vda') {
	return $quota ? $quota : '0';
    } else {
	return $quota."S";
    }
}

sub quota2num {
    my $self = shift;
    my $quota = $_[0];
    $quota =~ s/S$//i;
    return $quota;
}

sub mod {
    if(!$opt{username}){
        push @exp, { error => "Please input a user name for modify!" };
        output ;
    }
    my $email = $opt{username};
    my ($user,$domain) = split(/\@/,$email);
    my $password = $opt{password};
    my $quota = $opt{quota};
    my $ndquota = $opt{ndquota};
    my $expiredate = $opt{expire};
    my $ul = $mgr->get_user_info($email);

    if(!$ul){
        push @exp, { error => "User not exists!" };
        output ;
    }

    my $active = (defined $opt{active} ? $opt{active} : $ul->{active});
    my $name = (defined $opt{name} ? $opt{name} : $ul->{cn});
    my $question = defined $opt{question} ? $opt{question} : $ul->{question};
    my $answer = defined $opt{answer} ? $opt{answer} : $ul->{answer};

    #smtp,smtpd,pop3,imap,webmail,netdisk,pwdchange
    #PRIORITY: 1:disable, 2:enable
    my %services = (
     	'pwdchange' => $ul->{disablepwdchange},
		'smtpd' => $ul->{disablesmtpd},
		'smtp' => $ul->{disablesmtp},
		'webmail' => $ul->{disablewebmail},
		'netdisk' => $ul->{disablenetdisk},
		'pop3' => $ul->{disablepop3},
		'imap' => $ul->{disableimap}
	);
    #enable services,
    if ($opt{services}) {
	#smtp,smtpd,pop3,imap,webmail,netdisk,pwdchange
	#PRIORITY: 1:disable, 2:enable
	%services = (
       	'pwdchange' => 1,
		'smtpd' => 1,
		'smtp' => 1,
		'webmail' => 1,
		'netdisk' => 1,
		'pop3' => 1,
		'imap' => 1
	);
        my @sve = split(/,/,$opt{services});
        foreach(@sve){
	    if (exists $services{$_}){
	        $services{$_} = 0;
	    }
        }
    }

    if($ul){
        my $uid = $ul->{uidnumber};
        my $gid = $ul->{gidnumber};
        my @ttime = split(/ /,$ul->{expire});
        my $time = $ttime[1];
        $expiredate = $expiredate ? $expiredate." ".$time : $ul->{expire};
        $quota = $quota ? num2quota $quota : $ul->{quota};
        $password = $password ? $password : undef;
        my $netdiskquota = $ndquota ? num2quota $ndquota : $ul->{netdiskquota};
        push @exp, { type => "user",
                email => $email,
                name => $name,
                domain => $domain,
                uid => $uid,
                gid => $gid,
                expiredate => $expiredate,
                quota => $quota,
                question => $question,
                answer => $answer,
                netdiskquota => $netdiskquota,
                active => $active,
                disablepwdchange => $services{pwdchange},
                disablesmtpd => $services{smtpd},
                disablesmtp => $services{smtp},
                disablewebmail => $services{webmail},
                disablenetdisk => $services{netdisk},
                disablepop3 => $services{pop3},
                disableimap => $services{imap}
        };
        my $href = $exp[0];
        $href->{password} = $password if($password);

        my $rc = $mgr->modify_user(
        user => "$user\@$domain",
        domain => $domain,
        cn => $name,
        uidnumber => $uid,
        gidnumber => $gid,
        expire => $expiredate,
        passwd => $password,
        quota => $quota,
        question => $question,
        answer => $answer,
        netdiskquota => $netdiskquota,
        active => $active,
        disablepwdchange => $services{pwdchange},
        disablesmtpd => $services{smtpd},
        disablesmtp => $services{smtp},
        disablewebmail => $services{webmail},
        disablenetdisk => $services{netdisk},
        disablepop3 => $services{pop3},
        disableimap => $services{imap},
        );
        if($rc){
            $href->{status} = 0;
        }else{
            $href->{status} = 1;
        }
    }
    output ;
}

if($opt{mode}){
    switch ($opt{mode}){
	case "add" { add(); }
	case "badd" { badd(); }
	case "del" { del(); }
	case "bdel" { bdel(); }
	case "list" { list(); }
	case "show" { show(); }
	case "mod" { mod(); }
	case "help" { usage(); }
	else { usage(); }
    }
}else{
    usage ();
}
