#!/bin/sh
exec ${PERL-perl} -Swx $0 ${1+"$@"}

#!/usr/bin/perl -w
#   userinfo.pl: alias management
#	 Author: chifeng <chifeng At gmail.com>
#	   Date: 2008-01-06 15:39:00
#      Homepage: http://www.extmail.org
#	Version: 0.4
#
#
use vars qw($DIR);

BEGIN {
    my $path = $0;
    if ($path =~ s/tools\/[0-9a-zA-Z\-\_]+\.pl$//) {
        if ($path !~ /^\//) {
            $DIR = "./$path";
        } else {
            $DIR = $path;
        }
    } else {
        $DIR = '../';
    }
    unshift @INC, $DIR .'libs';
};

# use strict; # developing env
no warnings; # production environment
use POSIX qw(strftime);
use Ext::Mgr;
use CmdTools;
use Ext::DateTime qw(time2epoch epoch2time);
use Getopt::Long;
use Switch;
use IO::File;
require $DIR.'/tools/setid.pl';

my $ctx = CmdTools->new( config => $DIR . '/webman.cf', directory => $DIR );
my $c = \%Ext::Cfg;
my $mgr = $ctx->ctx; # backend object
my $basedir = $c->{SYS_MAILDIR_BASE};
my %opt = ();
my $set_user=$c->{SYS_DEFAULT_UID};
my $set_group=$c->{SYS_DEFAULT_GID};

Getopt::Long::Configure('no_ignore_case');
Getopt::Long::GetOptions(\%opt,
    'mode|m=s',
    'aliasname=s',
    'domain=s',
    'goto=s',
    'active=i',
    'setgid=s',
    'setuid=s',
    'quiet|qq',
) or exit 1;

sub output {
    my $type = $_[0];
    print "\n";
    for $href (@exp){
        foreach my $i ( keys %$href ){
            if( !$opt{mode} or $opt{help}){
                printf ("--%s = ", $i);
            }else{
                printf ("%s = ", $i);
            }
            printf ("%s", $href->{$i}),;
            print "\n";
        }
    }
    exit;
}
sub usage {
    push @exp, { mode => "add,del,list,show,mod,help",
        aliasname => "aliasname\@domain.tld",
        domain => "domain.tld",
        goto => "username\@domain.tld",
        active => "1 or 0",
        setgid => "vgroup",
        setuid => "vuser",
        quiet => "1 or 0"
    };
    output ;
}
if($opt{setgid} && $opt{setuid}){
    $set_user = $opt{setuid};
    $set_group = $opt{setgid};
}
set_gid($set_user);
set_uid($set_group);

sub addalias {
    my $aliasname = $_[0];
    my ($alias,$domain) = split(/@/,$aliasname);
    my $goto = $_[1];
    my $createdate = strftime("%Y-%m-%d %H:%M:%S", localtime);

    my $rc = $mgr->add_alias(
        alias => "$alias\@$domain",
        domain => $domain,
        goto => $goto,
        active => defined $opt{active} ? $opt{active} : 1,
        create => $createdate,
    );
    if($rc){
        return 0;
    }else{
        return 1;
    }
}

sub add {
    if($opt{aliasname}){
        my $aliasname = $opt{aliasname};
        my $goto = $opt{goto};
    if(!($opt{goto})){
        push @exp, { error => "goto can not Empty!" };
        output ;
    }
    if(addalias $aliasname,$goto){
        push @exp, { alias => $aliasname,
            goto => $goto,
            status => 1,
        };
        output ;
	}else{
        push @exp, { error => "Alias $aliasname add faild!" };
        output ;
	}
    }else{
        push @exp, { error => "Please input a alias for add!" };
        output ;
    }
}

sub delalias {
    my $aliasname = $_[0];
    if($mgr->get_alias_info($aliasname)){
        if($mgr->delete_alias($aliasname)){
            push @exp, { error => "$aliasname Deleted Faild!" };
            output ;
        }else{
            push @exp, { error => "$aliasname Deleted Success!" };
            output ;
        }
    }else{
        push @exp, { error => "$aliasname no exist!" };
        output ;
    }
}

sub del {
    if($opt{aliasname}){
        delalias $opt{aliasname};
    }else{
        push @exp, { error => "Please input a alias address to delete!" };
        output ;
    }
}

sub list {
    if($opt{domain}){
        my $domain = $opt{domain};
        if(!($mgr->get_domain_info($domain))){
            push @exp, { error => "$domain no exists!" };
	        output ;
        }
        my $ul = $mgr->get_aliases_list($domain);
        foreach my $u (@$ul) {
            my $r = $u->{goto};
            my $goto = ref $r ? join(',', @$r) : $r;
            push @exp, { alias => $u->{alias},
                goto => $goto,
                active => $u->{active},
            };
        }
        output ;
    }else{
        push @exp, { error => "Please input a domain name!" };
        output ;
    }
}

sub show {
    my $dms = [];
    if($opt{aliasname}){
        if(my $ul = $mgr->get_alias_info($opt{aliasname})){
            my $r = $ul->{goto};
            my $goto = ref $r ? join(',', @$r) : $r;
            push @exp, { type => "alias",
                email => $ul->{alias},
                goto => $goto,
                domain => $ul->{domain},
                active => $ul->{active},
            };
            output ;
        }else{
            push @exp, { error => "$opt{aliasname} no exist!" };
            output ;
        }
    }else{
        push @exp, { error => "Please input a aliasname to show!" };
        output ;
    }
}

sub mod {
    if(!($opt{aliasname})){
        push @exp, { error => "Please input a user name for modify!" };
        output ;
    }
    my $alias = $opt{aliasname};
    my $ul = $mgr->get_alias_info($alias);
    if(!$ul){
        push @exp, { error => "$alias not exists!" };
        output ;
    }

    my $active = defined $opt{active} ? $opt{active} : $ul->{active};
    if($ul){
        my $ogoto = ref $ul->{goto} ? @{$ul->{goto}} : $ul->{goto};
        my $goto = $opt{goto} ? $opt{goto} : $ogoto;
        push @exp, { alias => $alias,
            goto => $goto,
            active => $active,
            status => 1,
        };
        $mgr->modify_alias(
            alias => $alias,
            goto => $goto,
            active => $active,
        );
        output ;
    }
}

if($opt{mode}){
    switch ($opt{mode}){
        case "add" { add(); }
        case "del" { del(); }
        case "list" { list(); }
        case "show" { show(); }
        case "mod" { mod(); }
        case "help" { usage(); }
        else { usage(); }
    }
}else{
    usage ();
}
