function eURL(str) {
        var rv = ' '; // not '' for a NS bug!
        for (i=0; i < str.length; i++) {
                aChar=str.substring(i, i+1);
                switch(aChar) {
                        case '=': rv += "%3D"; break;
                        case '?': rv += "%3F"; break;
                        case '&': rv += "%26"; break;
                        default: rv += aChar;
                }
        }
        return rv.substring(1, rv.length);
}
