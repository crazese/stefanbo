FlashPioneer Video Chat Readme File
Copyright (C) 2001-2008 SourceTec Software Co., LTD.
All Rights Reserved

----------------------------------------------------------------
Table of Contents
      
    * Description
    * What's New 
    * Features 
    * System Requirements 
    * Installation 
    * Upgrade
    * License 
    * Contact 

----------------------------------------------------------------

DESCRIPTION

    FlashPioneer Video Chat is an audio and video chat solution based on Flash 
    media server. It helps you deploy an online community without any chat 
    client installation required. FlashPioneer Video Chat features in text 
    sound and video communication, real-time doodle and funny animation smiley 
    besides advanced functions of database integration, multi-language and 
    multi-platform support. The solution is a white brand system so it can be 
    fully customized at your requirements, in the appearance of chat client, 
    even the functions. With help of the detail documents, the installation is 
    easy and fast. The 5-user version is available for free.

----------------------------------------------------------------

WHAT'S NEW

    Version: FlashPioneer Video Chat 2.0 RC1
    Build Number: 81031
    New features and Improvement:
    * Rewrite by Flex and AS3.0
    * 


----------------------------------------------------------------

FEATURES

    1. Set up in Minutes
       * Base on Flash Media Server, step by step animation installation help, 
         building your online community in a few steps.
       * Multi-platform supported, Windows or Linux etc.
       * No client installation

    2. Easily Customizable
       * Display your logo
       * Determine the skin policy, color scheme and text style you prefer
       * Flexible chat window size
       * Multi-language supported

    3. Fast,  Private and Secure
       * Smooth audio & video stream support
       * Monitored by the administrator any improper actions will be prevented 
         in time.
       * User's Management including "Chat Setting", "Sound Setting", "Private 
         Setting" and user's profile.
       * One-to-one private Video/Audio Chat

    4. Rich User Experience
       * Real-time doodle
       * Funny smiley, animations and backgrounds
       * Multi-type room, "Public room", "Members Only", "Password Needed"


----------------------------------------------------------------

SYSTEM REQUIREMENTS

    Flash Media Server 2.0 Edition:
        Supported operating systems
            Windows 2000 Server 
            Windows 2003 Server
            Linux Red Hat Enterprise 3.0
            Linux Red Hat Enterprise 4.0
        Software Environment
            FMS Server 2.0 or a higher
        Hardware Requirements
            X86-compatible CPU (PIII, 1GHz or better)
            512 MB available RAM
            50 MB of available disk space


----------------------------------------------------------------

INSTALLATION 

    Products directory as following:
    /client                     Chat client program files
    /doc                        Documentation in PDF format
    /web
        /dotnet                 ASP.net edition remoting interface to database
        /amfphp                 PHP edition remoting interface to database
    /server
        /fms                    Chat server program of FMS edition


    For more detail information please read documents in doc folder

    Please visit http://www.flashpioneer.com/chat/help.htm for Administrator's 
    Guide Online Manual
    Please visit http://www.flashpioneer.com/chat/onlinehelp/help.htm for 
    User's Guide Online Help


----------------------------------------------------------------

UPGRADE

    We offer the absolutely free video chat of 5 users version with full 
    functions. You can use it for business communication, company internal 
    communication and personal communication. 

    For upgrade or purchase information of other versions please go to 
    http://www.flashpioneer.com/chat/index.htm  


----------------------------------------------------------------

LICENSE 

    Check out the license.txt for license information. 


----------------------------------------------------------------

CONTACT US 
          
    Web Site: http://www.flashpioneer.com/ 
    Tel: +86(27)67848991 
    Fax: +86(27)67848990
    Email: support@flashpioneer.com 
    Postal: 502, 5th Bld, International Enterprise Center (2)
            GuanShan 2nd Road
            Wuhan, Hubei 
            China 430074


End
