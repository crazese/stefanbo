﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Globalization;
using System.Text;
using com.TheSilentGroup.Fluorine;

namespace flashchat2
{

    [RemotingService("FlashPioneer Video Chat 2.0 Service")]
    public class chatService
    {
        private readonly string ConnStr;
        private readonly SqlConnection Conn;

        public chatService()
        {
            ConnStr = ConfigurationManager.ConnectionStrings["chatConn"].ToString();
            Conn = new SqlConnection(ConnStr);
        }

        private static bool checkKeys(Hashtable o, IEnumerable<string> keys)
        {
            foreach (string s in keys)
            {
                if (!o.ContainsKey(s))
                {
                    return false;
                }
            }
            return true;
        }

        /*
           功能：读取所有房间配置

           参数：无

         * 返回：Object - {succeed:Boolean, info:String, data:Array} 返回操作成功与否
                 succeed:Boolean - 表示操作成功与否
	         info:String - 提示信息
	         data:Array - 一个数组，其中包含所有Object形式的房间配置
                 形如：[oRoom:Object, oRoom:Object, ...]


	         oRoom = {rid:Uint,			- 房间ID
		          name:String,			- 房间名称/标题
		          icon:String,			- 房间图标URL
		          description:String,		- 房间说明
		          welcome:String,		- 登录房间时的欢迎语
		          administrators:String,	- 房间管理员，多个以“,”分开
		          password:String,		- 进入房间密码，为空表示不需要密码
		          enableInList:Boolean,		- 此房间名是否显示在房间列表中(用于租用私有房间)
		          enableJoin:Boolean,		- 是否允许登入(即房门功能)
		          enableGuest:Boolean,		- 是否允许游客
		          enableDeskLogin:Boolean,	- 是否允许以桌面应用程序(exe)的方式连接
		          enableRename:Boolean,		- 进入房间后是否允许更改昵称
	              maxOnline:Int,		- 允许的同时最大在线人数
		          dumbTime:Int,			- 禁止发言自动解锁更新，单位：秒
		          blockNames:Int,		- 帐号黑名单，多个之间以“,”分割
		          kickTime:Int,			- 被踢出帐号后多长更新解锁，单位：分钟
		          blockIps:String,		- IP黑名单，多个之间以“,”分割
		          kickIpTime:Int,		- 被房间管理员踢IP后多长更新解锁,单位:分钟
		          enterRoomSound:Boolean,	- 是否允许有人进入房间时提示音
		          quitRoomSound:Boolean,	- 是否允许有人退出房间时提示音
		          messageSound:Boolean,		- 是否允许有聊天信息时提示音
		          noticeSound:Boolean,		- 是否允许有系统消息时提示音
		          pluginCfgs:String,		- 一个数组，数组中每个元素均为一个XML(对应一个插件配置)
		          }
        */
        public Hashtable getAllRoomCfg()
        {
            Hashtable ro = new Hashtable();

            ArrayList al = new ArrayList();
            string sql = "SELECT * FROM fpchat_Rooms ORDER BY name";
            using (Conn)
            {
                try
                {
                    SqlCommand sc = new SqlCommand(sql, Conn);
                    Conn.Open();
                    SqlDataReader reader = sc.ExecuteReader();
                    if (reader == null)
                    {
                        ro.Add("succeed", false);
                        ro.Add("info", "RET_ERROR_007");
                        return ro;
                    }
                    while (reader.Read())
                    {
                        Hashtable ht = new Hashtable();
                        ht.Add("rid", reader["rid"]);
                        ht.Add("name", reader["name"]);
                        ht.Add("icon", reader["icon"]);
                        ht.Add("description", reader["description"]);
                        ht.Add("welcome", reader["welcome"]);
                        ht.Add("administrators", reader["administrators"]);
                        ht.Add("password", reader["password"]);
                        ht.Add("enableInList", reader["enableInList"]);
                        ht.Add("enableJoin", reader["enableJoin"]);
                        ht.Add("enableGuest", reader["enableGuest"]);
                        ht.Add("enableDeskLogin", reader["enableDeskLogin"]);
                        ht.Add("enableRename", reader["enableRename"]);
                        ht.Add("maxOnline", reader["maxOnline"]);
                        ht.Add("dumbTime", reader["dumbTime"]);
                        ht.Add("blockNames", reader["blockNames"]);
                        ht.Add("kickTime", reader["kickTime"]);
                        ht.Add("blockIps", reader["blockIps"]);
                        ht.Add("kickIpTime", reader["kickIpTime"]);
                        ht.Add("enterRoomSound", reader["enterRoomSound"]);
                        ht.Add("quitRoomSound", reader["quitRoomSound"]);
                        ht.Add("messageSound", reader["messageSound"]);
                        ht.Add("noticeSound", reader["noticeSound"]);
                        ht.Add("pluginCfgs", reader["pluginCfgs"]);

                        al.Add(ht);
                    }
                    reader.Close();
                    ro.Add("succeed",true);
                    ro.Add("data",al.ToArray());
                }
                catch (Exception ex)
                {
                    ro.Add("succeed",false);
                    ro.Add("info",ex.Message);
                }

            }
            return ro;
        }

        /*
           功能：保存指定的某个房间配置

           参数：oRoom:Object - 一个房间对象

           返回：Object - {succeed:Boolean, info:String} succeed表示操作成功与否，info表示提示信息(如果出错)
        */
        public Hashtable saveRoomCfg(Hashtable Room)
        {
            Hashtable ro = new Hashtable();
            if (!checkKeys(Room, new string[]{"rid","name","icon","description","welcome",
                                    "administrators","password","enableInList","enableJoin",
                                    "enableGuest","enableDeskLogin","enableRename","maxOnline",
                                    "dumbTime","blockNames","kickTime","blockIps","kickIpTime",
                                    "enterRoomSound","quitRoomSound","messageSound","noticeSound","pluginCfgs"}))
            {
                ro.Add("succeed", false);
                ro.Add("info", "RET_ERROR_001");
                return ro;
            }

            string sql = "SELECT name FROM fpchat_Rooms WHERE (rid = @Param)";
            using (Conn)
            {
                try
                {
                    SqlCommand sc = new SqlCommand(sql, Conn);
                    sc.Parameters.AddWithValue("@Param", Room["rid"]);
                    Conn.Open();
                    object s = sc.ExecuteScalar();

                    StringBuilder sb;
                    if (s == null)
                    {
                        sb = new StringBuilder();
                        sb.Append("INSERT INTO fpchat_Rooms ");
                        sb.Append("(rid, name, icon, description, welcome, administrators, password, enableInList, ");
                        sb.Append("enableJoin, enableGuest, enableDeskLogin, enableRename, maxOnline, dumbTime, ");
                        sb.Append("blockNames, kickTime, blockIps, kickIpTime, enterRoomSound, quitRoomSound, ");
                        sb.Append("messageSound, noticeSound, pluginCfgs) ");
                        sb.Append("VALUES (@rid,@name,@icon,@description,@welcome,@administrators,@password,");
                        sb.Append("@enableInList,@enableJoin,@enableGuest,@enableDeskLogin,@enableRename,");
                        sb.Append("@maxOnline,@dumbTime,@blockNames,@kickTime,@blockIps,@kickIpTime,");
                        sb.Append("@enterRoomSound,@quitRoomSound,@messageSound,@noticeSound,@pluginCfgs)");
                    }else
                    {
                        sb = new StringBuilder();
                        sb.Append("UPDATE fpchat_Rooms ");
                        sb.Append("SET name = @name, icon = @icon, description = @description, ");
                        sb.Append("welcome = @welcome, administrators = @administrators, password = @password, ");
                        sb.Append("enableInList = @enableInList, enableJoin = @enableJoin, ");
                        sb.Append("enableGuest = @enableGuest, enableDeskLogin = @enableDeskLogin, ");
                        sb.Append("enableRename = @enableRename, maxOnline = @maxOnline, dumbTime = @dumbTime, ");
                        sb.Append("blockNames = @blockNames, kickTime = @kickTime, blockIps = @blockIps, ");
                        sb.Append("kickIpTime = @kickIpTime, enterRoomSound = @enterRoomSound, ");
                        sb.Append("quitRoomSound = @quitRoomSound, messageSound = @messageSound, ");
                        sb.Append("noticeSound = @noticeSound, pluginCfgs = @pluginCfgs WHERE (rid = @rid)");
                    }

                    SqlCommand scmd = new SqlCommand(sb.ToString(), Conn);
                    scmd.Parameters.AddWithValue("@rid", Room["rid"]);
                    scmd.Parameters.AddWithValue("@name", Room["name"]);
                    scmd.Parameters.AddWithValue("@icon", Room["icon"] ?? DBNull.Value);
                    scmd.Parameters.AddWithValue("@description", Room["description"] ?? DBNull.Value);
                    scmd.Parameters.AddWithValue("@welcome", Room["welcome"] ?? DBNull.Value);
                    scmd.Parameters.AddWithValue("@administrators", Room["administrators"] ?? DBNull.Value);
                    scmd.Parameters.AddWithValue("@password", Room["password"] ?? DBNull.Value);
                    scmd.Parameters.AddWithValue("@enableInList", Room["enableInList"] ?? DBNull.Value);
                    scmd.Parameters.AddWithValue("@enableJoin", Room["enableJoin"] ?? DBNull.Value);
                    scmd.Parameters.AddWithValue("@enableGuest", Room["enableGuest"] ?? DBNull.Value);
                    scmd.Parameters.AddWithValue("@enableDeskLogin", Room["enableDeskLogin"] ?? DBNull.Value);
                    scmd.Parameters.AddWithValue("@enableRename", Room["enableRename"] ?? DBNull.Value);
                    scmd.Parameters.AddWithValue("@maxOnline", Room["maxOnline"] ?? DBNull.Value);
                    scmd.Parameters.AddWithValue("@dumbTime", Room["dumbTime"] ?? DBNull.Value);
                    scmd.Parameters.AddWithValue("@blockNames", Room["blockNames"] ?? DBNull.Value);
                    scmd.Parameters.AddWithValue("@kickTime", Room["kickTime"] ?? DBNull.Value);
                    scmd.Parameters.AddWithValue("@blockIps", Room["blockIps"] ?? DBNull.Value);
                    scmd.Parameters.AddWithValue("@kickIpTime", Room["kickIpTime"] ?? DBNull.Value);
                    scmd.Parameters.AddWithValue("@enterRoomSound", Room["enterRoomSound"] ?? DBNull.Value);
                    scmd.Parameters.AddWithValue("@quitRoomSound", Room["quitRoomSound"] ?? DBNull.Value);
                    scmd.Parameters.AddWithValue("@messageSound", Room["messageSound"] ?? DBNull.Value);
                    scmd.Parameters.AddWithValue("@noticeSound", Room["noticeSound"] ?? DBNull.Value);
                    scmd.Parameters.AddWithValue("@pluginCfgs", Room["pluginCfgs"] ?? DBNull.Value);

                    int result = scmd.ExecuteNonQuery();
                    if (result > 0)
                    {
                        ro.Add("succeed", true);
                    }else
                    {
                        ro.Add("succeed",false);
                        ro.Add("info", "RET_ERROR_005");
                    }
                }
                catch (Exception ex)
                {
                    ro.Add("succeed",false);
                    ro.Add("info",ex.Message);
                }

            }
            return ro;
        }

        /*
           功能：删除某个房间配置

           参数：roomID:Uint - 房间ID

           返回：Object - {succeed:Boolean, info:String} 其中，succeed表示操作成功与否，info表示提示信息(如果出错)
        */
        public Hashtable deleteRoomCfg(int RoomID)
        {
            Hashtable ro = new Hashtable();

            string sql = "DELETE FROM fpchat_Rooms WHERE (rid = @Param)";

            using (Conn)
            {
                try
                {
                    SqlCommand sc = new SqlCommand(sql, Conn);
                    sc.Parameters.AddWithValue("@Param", RoomID);
                    Conn.Open();
                    int result = sc.ExecuteNonQuery();
                    if (result>0)
                    {
                        ro.Add("succeed",true);
                    }else
                    {
                        ro.Add("succeed", false);
                        ro.Add("info", "RET_ERROR_005");
                    }
                }catch(Exception ex)
                {
                    ro.Add("succeed", false);
                    ro.Add("info", ex.Message);
                }
            }

            // clear that room's log
            deleteTextChatHistory(RoomID);

            return ro;
        }

        /*
           功能：检验登录

           参数：parasObject:Object - 用户登录表单提交的数据
                 parasObject = {type:String,	- "guest"/"membet"，表示是游客还是会员登录。type="guest"时，应检测游客使用的
         * 名称是否与已注册会员名重复
	                        name:String,	- 用户名
			        password:String	- 密码
			        }

           返回：Object - {succeed:Boolean, info:String, data:Object} 返回登录是否成功和用户资料
                 其中，succeed表示操作成功与否，info表示提示信息(如果出错)，data为登录成功的会员用户信息(参见com\model\MUser.asc)
                 data = {name:String, password:String, email:String, sex:String, avatar:String, level:Uint, friendList:String,
         * blockList,String}
        */
        public Hashtable login(Hashtable passObj)
        {
            Hashtable ro = new Hashtable();
            if (!checkKeys(passObj,new string[]{"type","name","password"}))
            {
                ro.Add("succeed",false);
                ro.Add("info", "RET_ERROR_001");
                return ro;
            }

            string type = passObj["type"].ToString().ToLower();
            string name = passObj["name"].ToString().ToLower();
            string password = passObj["password"].ToString().ToLower();

            string sql = "SELECT * FROM fpchat_Users WHERE (name = @Param)";

            using (Conn)
            {
                try
                {
                    SqlCommand sc = new SqlCommand(sql, Conn);
                    sc.Parameters.AddWithValue("@Param", name);
                    Conn.Open();
                    SqlDataReader reader = sc.ExecuteReader();
                    Hashtable data = null;
                    if (reader == null)
                    {
                        ro.Add("succeed",false);
                        ro.Add("info","RET_ERROR_007");
                        return ro;
                    }
                    bool b = reader.Read();
                    if (b)
                    {
                        data = new Hashtable();
                        data.Add("name", reader["name"]);
                        data.Add("email", reader["email"]);
                        data.Add("sex", reader["sex"]);
                        data.Add("avatar", reader["avatar"]);
                        data.Add("level", reader["level"]);
                        data.Add("friendList", reader["friendList"]);
                        data.Add("blockList", reader["blockList"]);
                    }

                    if (type == "guest")
                    {
                        if (b)
                        {
                            ro.Add("succeed", false);
                            ro.Add("info", "RES_ERROR_008");
                        }
                        else
                        {
                            ro.Add("succeed", true);
                        }
                    }else
                    {
                        if (b)
                        {
                            if (password == (string) reader["password"])
                            {
                                ro.Add("succeed",true);
                                ro.Add("data",data);
                            }else
                            {
                                ro.Add("succeed",false);
                                ro.Add("info","RES_ERROR_010");
                            }
                        }else
                        {
                            ro.Add("succeed",false);
                            ro.Add("info","RES_ERROR_009");
                        }
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                    ro.Add("succeed",false);
                    ro.Add("info",ex.Message);
                }
            }
            return ro;
        }

        /*
           功能：用户注册

           参数：parasObject:Object - 用户注册表单提交的数据
                 parasObject = {name:String,		- 用户名
	                        password:String,	- 密码
			        email:String,		- EMAIL
			        sex:String,		- 性别
			        avatar:String,		- 头像标识符
			        level:Uint		- 用户级别
			        }

           返回：Object - {succeed:Boolean, info:String} 返回注册成功与否
                 其中，succeed表示操作成功与否，info表示提示信息(如果出错)
        */
        public Hashtable register(Hashtable passObj)
        {
            Hashtable ro = new Hashtable();
            if (!checkKeys(passObj, new string[] { "name", "password", "email", "sex", "avatar", "level" }))
            {
                ro.Add("succeed",false);
                ro.Add("info", "RET_ERROR_001");
                return ro;
            }

            using (Conn)
            {
                try
                {
                    SqlCommand sc;
                    string sql = "SELECT id FROM fpchat_Users WHERE (name = @name)";
                    sc = new SqlCommand(sql, Conn);
                    sc.Parameters.AddWithValue("@name", passObj["name"]);
                    Conn.Open();
                    object i = sc.ExecuteScalar();
                    if (i != null)
                    {
                        ro.Add("succeed",false);
                        ro.Add("info","RES_ERROR_011");
                        return ro;
                    }

                    StringBuilder sb = new StringBuilder();
                    sb.Append("INSERT INTO fpchat_Users (name, password, email, sex, avatar, [level]) ");
                    sb.Append("VALUES (@name,@password,@email,@sex,@avatar,@level)");

                    sc = new SqlCommand(sb.ToString(), Conn);
                    sc.Parameters.AddWithValue("@name", passObj["name"]);
                    sc.Parameters.AddWithValue("@password", passObj["password"]);
                    sc.Parameters.AddWithValue("@email", passObj["email"]);
                    sc.Parameters.AddWithValue("@sex", passObj["sex"]);
                    sc.Parameters.AddWithValue("@avatar", passObj["avatar"]);
                    sc.Parameters.AddWithValue("@level", passObj["level"]);

                    int result = sc.ExecuteNonQuery();
                    if (result > 0)
                    {
                        ro.Add("succeed", true);
                    }
                    else
                    {
                        ro.Add("succeed", false);
                        ro.Add("info", "RET_ERROR_005");
                    }
                }
                catch (Exception ex)
                {
                    ro.Add("succeed", false);
                    ro.Add("info", ex.Message);
                }
            }

            return ro;
        }

        /*
           功能：读取用户资料

           参数：strUserName:String - 会员帐号名称

           返回：Object - {succeed:Boolean, info:String, data:Object} 返回此会员资料
                 其中，succeed表示操作成功与否，info表示提示信息(如果出错)，data为此会员资料(参见com\model\MUser.asc)
                 data = {password:String, email:String, sex:String, avatar:String, level:Uint,
         * friendList:String, blockList,String}
        */
        public Hashtable loadUserData(string Username)
        {
            Hashtable ro = new Hashtable();
            if (string.IsNullOrEmpty(Username))
            {
                ro.Add("succeed", false);
                ro.Add("info", "RET_ERROR_001");
                return ro;
            }

            string sql = "SELECT password, email, sex, avatar, [level], friendList, blockList FROM fpchat_Users WHERE (name = @name)";

            using (Conn)
            {
                try
                {
                    SqlCommand sc = new SqlCommand(sql,Conn);
                    sc.Parameters.AddWithValue("@name", Username);
                    Conn.Open();
                    SqlDataReader reader = sc.ExecuteReader();
                    if (reader == null)
                    {
                        ro.Add("succeed", false);
                        ro.Add("info", "RET_ERROR_007");
                        return ro;
                    }
                    if (reader.Read())
                    {
                        Hashtable data = new Hashtable();
                        data.Add("password", reader["pasword"]);
                        data.Add("email", reader["email"]);
                        data.Add("sex", reader["sex"]);
                        data.Add("avatar", reader["avatar"]);
                        data.Add("level", reader["level"]);
                        data.Add("friendList", reader["friendList"]);
                        data.Add("blockList", reader["blockList"]);

                        ro.Add("succeed", true);
                        ro.Add("data", data);
                    }
                    else
                    {
                        ro.Add("succeed", false);
                        ro.Add("info", "RET_ERROR_003");
                    }

                }
                catch (Exception ex)
                {
                    ro.Add("succeed", false);
                    ro.Add("info", ex.Message);
                }
            }

            return ro;
        }

        /*
           功能：保存某个用户资料

           参数：oUser:Object - 一个会员MClient对象
	         oUser = {
	                  name:String,		- 用户名
		          password:String,	- 密码
		          email:String,		- EMAIL
		          sex:String,		- 性别
		          avatar:String,	- 头像标识符
		          level:Uint,		- 用户级别
		          friendList:String,	- 好友名单，多个好友间用“,”分割
		          blockList,String	- 黑名单，多个之间用“,”分割
		          }

           返回：Object - {succeed:Boolean, info:String} 返回操作成功与否
                 其中，succeed表示操作成功与否，info表示提示信息(如果出错)
        */
        public Hashtable saveUserData(Hashtable User)
        {
            Hashtable ro = new Hashtable();
            if (!checkKeys(User, new string[] { "name", "password", "email", "sex", "avatar", "level", "friendList", "blockList" }))
            {
                ro.Add("succeed", false);
                ro.Add("info", "RET_ERROR_001");
                return ro;
            }

            string sql = "SELECT id FROM fpchat_Users WHERE (name = @Param)";
            using (Conn)
            {
                try
                {
                    SqlCommand sc = new SqlCommand(sql, Conn);
                    sc.Parameters.AddWithValue("@Param", User["name"]);
                    Conn.Open();
                    object i = sc.ExecuteScalar();

                    StringBuilder sb;
                    if (i == null)
                    {
                        sb = new StringBuilder();
                        sb.Append("INSERT INTO fpchat_Users ");
                        sb.Append("(name, password, email, sex, avatar, [level], friendList, blockList) ");
                        sb.Append("VALUES (@name,@password,@email,@sex,@avatar,@level,@friendList,@blockList)");
                    }
                    else
                    {
                        sb = new StringBuilder();
                        sb.Append("UPDATE fpchat_Users ");
                        sb.Append("SET password = @password, email = @email, sex = @sex, ");
                        sb.Append("avatar = @avatar, [level] = @level, friendList = @friendList, ");
                        sb.Append("blockList = @blockList WHERE (name = @name)");
                    }

                    SqlCommand scmd = new SqlCommand(sb.ToString(), Conn);
                    scmd.Parameters.AddWithValue("@name", User["name"]);
                    scmd.Parameters.AddWithValue("@password", User["password"] ?? DBNull.Value);
                    scmd.Parameters.AddWithValue("@email", User["email"] ?? DBNull.Value);
                    scmd.Parameters.AddWithValue("@sex", User["sex"] ?? DBNull.Value);
                    scmd.Parameters.AddWithValue("@avatar", User["avatar"] ?? DBNull.Value);
                    scmd.Parameters.AddWithValue("@level", User["level"] ?? DBNull.Value);
                    scmd.Parameters.AddWithValue("@friendList", User["friendList"] ?? DBNull.Value);
                    scmd.Parameters.AddWithValue("@blockList", User["blockList"] ?? DBNull.Value);

                    int result = scmd.ExecuteNonQuery();
                    if (result > 0)
                    {
                        ro.Add("succeed", true);
                    }
                    else
                    {
                        ro.Add("succeed", false);
                        ro.Add("info", "RET_ERROR_005");
                    }
                }
                catch (Exception ex)
                {
                    ro.Add("succeed", false);
                    ro.Add("info", ex.Message);
                }

            }


            return ro;
        }

        /*
           功能：删除某个用户的资料

           参数：strUserName:String - 用户名

           返回：Object - {succeed:Boolean, info:String} 其中，succeed表示操作成功与否，info表示提示信息(如果出错)
        */
        public Hashtable deleteUserData(string Username)
        {
            Hashtable ro = new Hashtable();
            if (string.IsNullOrEmpty(Username))
            {
                ro.Add("succeed", false);
                ro.Add("info", "RET_ERROR_001");
                return ro;
            }

            string sql = "DELETE FROM fpchat_Users WHERE (name = @Param)";

            using (Conn)
            {
                try
                {
                    SqlCommand sc = new SqlCommand(sql, Conn);
                    sc.Parameters.AddWithValue("@Param", Username);
                    Conn.Open();
                    int result = sc.ExecuteNonQuery();
                    if (result > 0)
                    {
                        ro.Add("succeed", true);
                    }
                    else
                    {
                        ro.Add("succeed", false);
                        ro.Add("info", "RET_ERROR_003");
                    }
                }
                catch (Exception ex)
                {
                    ro.Add("succeed", false);
                    ro.Add("info", ex.Message);
                }
            }

            return ro;
        }

        /*
           功能：返回指定分页用户资料数据列表

           参数：intPageSize:Uint - 每页显示多少条记录
	         intPageIndex:Uint - 当前要显示的页次
	         strKeyword:String - 搜索关键词(搜索用户名)

           返回：Object - {succeed:Boolean, info:Object, data:Array} 返回操作成功与否
                 succeed:Boolean - 表示操作成功与否
	            info:Object - 提示信息(如果出错) 或 {PageIndex:Uint, PageTotal:Uint} (如果成功)
		        PageIndex:Uint - 当前页
		        PageTotal:Uint - 总页数
	         data:Array - 返回的用户资料数组，形如 [oUser, oUser, ...]
        */
        public Hashtable getAccountList(int PageSize, int PageIndex, string Keyword)
        {
            bool b = string.IsNullOrEmpty(Keyword);

            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT TOP (@pagesize) name, password, email, sex, avatar, [level], friendList, blockList ");
            sb.Append("FROM (SELECT *,ROW_NUMBER() OVER (ORDER BY name) AS rowNum FROM fpchat_Users ) AS tempTable ");
            sb.Append("WHERE (rowNum > @pageprev)");
            if (!b)
            {
                sb.Append(" AND (name LIKE '%'+@key+'%')");
            }

            Hashtable ro = new Hashtable();
            using (Conn)
            {
                try
                {
                    SqlCommand sumsc;
                    string sql;
                    if (b)
                    {
                        sql = "SELECT COUNT(*) AS C FROM fpchat_Users";
                        sumsc = new SqlCommand(sql, Conn);
                    }
                    else
                    {
                        sql = "SELECT COUNT(*) AS C FROM fpchat_Users WHERE (name LIKE '%'+@key+'%')";
                        sumsc = new SqlCommand(sql, Conn);
                        sumsc.Parameters.AddWithValue("@key", Keyword);
                    }
                    Conn.Open();

                    int sum = (int) sumsc.ExecuteScalar();
                    if (sum == 0)
                    {
                        ro.Add("succeed", true);
                        Hashtable temp = new Hashtable();
                        temp.Add("PageIndex", 0);
                        temp.Add("PageTotal", 0);
                        ro.Add("info",temp);
                        ro.Add("data",null);
                        return ro;
                    }
                    int pagecount = (sum + PageSize - 1) / PageSize;

                    if (PageIndex > pagecount)
                    {
                        PageIndex = pagecount;
                    }else if(PageIndex<1)
                    {
                        PageIndex = 1;
                    }

                    int PagePrev = PageSize * (PageIndex - 1);
                    SqlCommand sc = new SqlCommand(sb.ToString(),Conn);
                    sc.Parameters.AddWithValue("@pagesize", PageSize);
                    sc.Parameters.AddWithValue("@pageprev", PagePrev);
                    if (!b) sc.Parameters.AddWithValue("@key", Keyword);

                    SqlDataReader reader = sc.ExecuteReader();
                    if (reader == null)
                    {
                        ro.Add("succeed", false);
                        ro.Add("info", "RET_ERROR_007");
                        return ro;
                    }
                    ArrayList al = new ArrayList();
                    while (reader.Read())
                    {
                        Hashtable ht = new Hashtable();
                        ht.Add("name",reader["name"]);
                        ht.Add("password", reader["password"]);
                        ht.Add("email", reader["email"]);
                        ht.Add("sex", reader["sex"]);
                        ht.Add("avatar", reader["avatar"]);
                        ht.Add("level", reader["level"]);
                        ht.Add("friendList", reader["friendList"]);
                        ht.Add("blockList", reader["blockList"]);

                        al.Add(ht);
                    }
                    Hashtable h = new Hashtable();
                    h.Add("PageIndex", PageIndex);
                    h.Add("PageTotal", pagecount);

                    ro.Add("succeed",true);
                    ro.Add("info",h);
                    ro.Add("data",al.ToArray());
                }
                catch (Exception ex)
                {
                    ro.Add("succeed", false);
                    ro.Add("info", ex.Message);
                }
            }

            return ro;
        }

        /*
           功能：保存一条聊天记录

           参数：intRoomId:Uint,		- 当前房间ID
	         oMsg:Object - 一条聊天信息
	         oMsg = {
	                 strFromWho:String,	- 发送方帐号名称
		         strToWho:String,	- 接收方帐号名称
		         strMessage:String,	- 消息内容
		         strFace:String,	- 表情
		         blnPrivate:Boolean,	- 是否悄悄话
		         strFont:String,	- 字体
		         strSize:String,	- 大小
		         strColor:String,	- 颜色
		         blnBold:Boolean,	- 加粗
		         blnItalics:Boolean,	- 斜体
		         blnUnderline:Boolean	- 下划线
                 strFromIP:String,	- 发送方IP地址
                 strTime   - 日期
		         }

           返回：Object - {succeed:Boolean, info:String} 返回操作成功与否
                 其中，succeed表示操作成功与否，info表示提示信息(如果出错)
        */
        public Hashtable addTextChatHistory(int RoomID, Hashtable Msg)
        {
            Hashtable ro = new Hashtable();
            if (!checkKeys(Msg, new string[] { "strFromWho", "strFromIP", "strToWho", "strMessage", "strFace",
                                        "blnPrivate", "strFont", "strSize", "strColor", "blnBold",
                                        "blnItalics", "blnUnderline", "strTime"}))
            {
                ro.Add("succeed", false);
                ro.Add("info", "RET_ERROR_001");
                return ro;
            }

            using (Conn)
            {
                try
                {
                    SqlCommand sc;
                    string sql = "SELECT name FROM fpchat_Rooms WHERE (rid = @rid)";
                    sc = new SqlCommand(sql, Conn);
                    sc.Parameters.AddWithValue("@rid", RoomID);
                    Conn.Open();
                    object i = sc.ExecuteScalar();
                    if (i == null)
                    {
                        ro.Add("succeed", false);
                        ro.Add("info", "RET_ERROR_008");
                        return ro;
                    }

                    StringBuilder sb = new StringBuilder();
                    sb.Append("INSERT INTO fpchat_Logs ");
                    sb.Append("(roomId, strFromWho, strFromIP, strToWho, strMessage, strFace, blnPrivate, strFont, ");
                    sb.Append("strSize, strColor, blnBold, blnItalics, blnUnderline, date) ");
                    sb.Append("VALUES (@roomId,@strFromWho,@strFromIP,@strToWho,@strMessage,@strFace,@blnPrivate,");
                    sb.Append("@strFont,@strSize,@strColor,@blnBold,@blnItalics,@blnUnderline,@date)");

                    DateTimeFormatInfo culture = new CultureInfo("en-US", false).DateTimeFormat;
                    DateTime d;
                    if (Msg["strTime"] == null)
                    {
                        d = DateTime.Now;
                    }
                    else
                    {
                        d = DateTime.Parse(Msg["strTime"].ToString(), culture);
                    }

                    sc = new SqlCommand(sb.ToString(), Conn);
                    sc.Parameters.AddWithValue("@roomId", RoomID);
                    sc.Parameters.AddWithValue("@strFromWho", Msg["strFromWho"] ?? DBNull.Value);
                    sc.Parameters.AddWithValue("@strFromIP", Msg["strFromIP"] ?? DBNull.Value);
                    sc.Parameters.AddWithValue("@strToWho", Msg["strToWho"] ?? DBNull.Value);
                    sc.Parameters.AddWithValue("@strMessage", Msg["strMessage"] ?? DBNull.Value);
                    sc.Parameters.AddWithValue("@strFace", Msg["strFace"] ?? DBNull.Value);
                    sc.Parameters.AddWithValue("@blnPrivate", Msg["blnPrivate"] ?? DBNull.Value);
                    sc.Parameters.AddWithValue("@strFont", Msg["strFont"] ?? DBNull.Value);
                    sc.Parameters.AddWithValue("@strSize", Msg["strSize"] ?? DBNull.Value);
                    sc.Parameters.AddWithValue("@strColor", Msg["strColor"] ?? DBNull.Value);
                    sc.Parameters.AddWithValue("@blnBold", Msg["blnBold"] ?? DBNull.Value);
                    sc.Parameters.AddWithValue("@blnItalics", Msg["blnItalics"] ?? DBNull.Value);
                    sc.Parameters.AddWithValue("@blnUnderline", Msg["blnUnderline"] ?? DBNull.Value);
                    sc.Parameters.AddWithValue("@date", d);

                    int result = sc.ExecuteNonQuery();
                    if (result > 0)
                    {
                        ro.Add("succeed", true);
                    }
                    else
                    {
                        ro.Add("succeed", false);
                        ro.Add("info", "RET_ERROR_005");
                    }
                }
                catch (Exception ex)
                {
                    ro.Add("succeed", false);
                    ro.Add("info", ex.Message);
                }
            }

            return ro;
        }

        /*
           功能：返回指定分页聊天记录数据列表

           参数：intRoomId:Uint - 房间ID
                 intPageSize:Uint - 每页显示多少条记录
	         intPageIndex:Uint - 当前要显示的页次
	         strKeyword:String - 搜索关键词
	         intKeyType:Uint - 关键词类型(0=搜索聊天内容，1=发送方用户名，2=接收方用户名)
	         strTimeFrom:Date - 时间段开始时间
	         strTimeFrom:Date - 时间段结束时间

           返回：Object - {succeed:Boolean, info:String, data:Array} 返回操作成功与否
                 succeed:Boolean - 表示操作成功与否
	         info:String - 提示信息(如果出错) 或 {PageIndex:Uint, PageTotal:Uint} (如果成功)
		        PageIndex:Uint - 当前页
		        PageTotal:Uint - 总页数
	         data:Array - 返回的聊天记录数组，形如 [oMsg, oMsg, ...]
        */
        public Hashtable getTextChatHistoryList(int RoomID, int PageSize, int PageIndex, string Keyword,
            int KeyType, string TimeFrom, string TimeTo)
        {
            Hashtable ro = new Hashtable();

            string sql = "SELECT TOP (@pagesize) strFromWho, strFromIP, strToWho, strMessage, blnPrivate, date ";
            sql += "FROM (SELECT *,ROW_NUMBER() OVER (ORDER BY date DESC) AS rowNum FROM fpchat_Logs ) AS tempTable ";

            string sumsql = "SELECT COUNT(*) AS C FROM fpchat_Logs ";

            StringBuilder sbCondi = new StringBuilder();
            sbCondi.Append("WHERE (roomId = @roomId) ");
            //
            bool a = !string.IsNullOrEmpty(Keyword);
			bool b = (!String.IsNullOrEmpty(TimeFrom));
            bool c = (!String.IsNullOrEmpty(TimeTo));
            //
            if (a)
            {
                switch (KeyType)
                {
                    case 0:
                        sbCondi.Append("AND (strMessage LIKE '%'+@key+'%') ");
                        break;
                    case 1:
                        sbCondi.Append("AND (strFromWho LIKE '%'+@key+'%') ");
                        break;
                    case 2:
                        sbCondi.Append("AND (strToWho LIKE '%'+@key+'%') ");
                        break;
                }
            }
            //
            DateTimeFormatInfo culture = new CultureInfo("en-US", false).DateTimeFormat;
            culture.DateSeparator = "/";

            DateTime df = DateTime.MinValue;
            DateTime dt = DateTime.MaxValue;
            if (b)
            {
                sbCondi.Append("AND (date >= @dateFrom) ");
                df = DateTime.Parse(TimeFrom, culture);
            }
            if (c)
            {
                sbCondi.Append("AND (date <= @dateTo) ");
                dt = DateTime.Parse(TimeTo, culture);
            }
            //
            using (Conn)
            {
                try
                {
                    SqlCommand sumsc = new SqlCommand(sumsql + sbCondi,Conn);
                    sumsc.Parameters.AddWithValue("@roomId", RoomID);
                    if (a)
                        sumsc.Parameters.AddWithValue("@key", Keyword);
                    if (b)
                        sumsc.Parameters.AddWithValue("@dateFrom", df);
                    if (c)
                        sumsc.Parameters.AddWithValue("@dateTo", dt);
                    Conn.Open();

                    int sum = (int) sumsc.ExecuteScalar();
                    if (sum == 0)
                    {
                        ro.Add("succeed", true);
                        Hashtable temp = new Hashtable();
                        temp.Add("PageIndex", 0);
                        temp.Add("PageTotal", 0);
                        ro.Add("info",temp);
                        ro.Add("data",null);
                        return ro;
                    }
                    int pagecount = (sum + PageSize - 1) / PageSize;

                    if (PageIndex > pagecount)
                    {
                        PageIndex = pagecount;
                    }
                    else if (PageIndex < 1)
                    {
                        PageIndex = 1;
                    }
                    int PagePrev = PageSize * (PageIndex - 1);

                    sbCondi.Append("AND (rowNum > @pageprev)");
                    SqlCommand sc = new SqlCommand(sql + sbCondi, Conn);
                    sc.Parameters.AddWithValue("@pagesize", PageSize);
                    sc.Parameters.AddWithValue("@pageprev", PagePrev);
                    sc.Parameters.AddWithValue("@roomId", RoomID);
                    if (a)
                        sc.Parameters.AddWithValue("@key", Keyword);
                    if (b)
                        sc.Parameters.AddWithValue("@dateFrom", df);
                    if (c)
                        sc.Parameters.AddWithValue("@dateTo", dt);
                    SqlDataReader reader = sc.ExecuteReader();
                    if (reader == null)
                    {
                        ro.Add("succeed", false);
                        ro.Add("info", "RET_ERROR_007");
                        return ro;
                    }

                    ArrayList al = new ArrayList();
                    while (reader.Read())
                    {
                        DateTime d = (DateTime) reader["date"];

                        Hashtable ht = new Hashtable();
                        ht.Add("strFromWho", reader["strFromWho"]);
                        ht.Add("strFromIP", reader["strFromIP"]);
                        ht.Add("strToWho", reader["strToWho"]);
                        ht.Add("strMessage", reader["strMessage"]);
                        ht.Add("blnPrivate", reader["blnPrivate"]);
                        ht.Add("strTime", d.ToString("MM/dd/yyyy HH:mm:ss", culture));

                        al.Add(ht);
                    }
                    Hashtable h = new Hashtable();
                    h.Add("PageIndex", PageIndex);
                    h.Add("PageTotal", pagecount);

                    ro.Add("succeed", true);
                    ro.Add("info", h);
                    ro.Add("data", al.ToArray());
                }
                catch (Exception ex)
                {
                    ro.Add("succeed", false);
                    ro.Add("info", ex.Message);
                }
            }

            return ro;
        }

        /*
           功能：删除某个房间的聊天记录

           参数：intRoomId:Uint - 房间ID

           返回：Object - {succeed:Boolean, info:String} 其中，succeed表示操作成功与否，info表示提示信息(如果出错)
        */
        public Hashtable deleteTextChatHistory(int RoomID)
        {
            Hashtable ro = new Hashtable();

            string sql = "DELETE FROM fpchat_Logs WHERE (roomId = @Param)";

            using (Conn)
            {
                try
                {
                    SqlCommand sc = new SqlCommand(sql, Conn);
                    sc.Parameters.AddWithValue("@Param", RoomID);
                    Conn.Open();
                    int result = sc.ExecuteNonQuery();
                    if (result > 0)
                    {
                        ro.Add("succeed", true);
                    }
                    else
                    {
                        ro.Add("succeed", false);
                        ro.Add("info", "RET_ERROR_005");
                    }
                }
                catch (Exception ex)
                {
                    ro.Add("succeed", false);
                    ro.Add("info", ex.Message);
                }
            }

            return ro;
        }

    }

}
