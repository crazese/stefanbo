<?php
set_time_limit(600);
include 'function.php';
