<?php
//积分奖励$lscs（连胜次数）

