<?php
header("location:{$_SC['backUrl']}"); 
?>
