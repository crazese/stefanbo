<?php
define('STORE_NBR', '2237'); // 2237 1025
define('PROD_NBR', '6200');  // 6200 6001
define('PROD_NAME', '元宝'); // 元宝 联调商品
define('PAYKEY', 'irWH_sLZlhvmEJAgJKWhpxISm2CBVaXUdDsPJm4L8r7qLR9gDy2PnNxJRq50N5pY'); // 测试环境 e_qxD7YorM_XfjQfieowr1ifQ1_msS17pARimOKEpszJIGQ3axxf6q1MJKuNrvIs
?>