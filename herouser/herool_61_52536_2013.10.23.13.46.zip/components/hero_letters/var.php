<?php
// 闯关类型值和可以抽奖的状态值
define('CG_TYPE_VALUE', 1);
define('CJ_TYPE_VALUE', 26);

// 每页显示消息数量
//define('SHOW_MESSAGE_BY_PAGE', 2);