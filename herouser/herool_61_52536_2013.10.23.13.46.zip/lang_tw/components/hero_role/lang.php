<?php
static $role_lang = array(
	'saveRoleInfo_1' => '朱貴',
	'saveRoleInfo_2' => '張順',
	'saveRoleInfo_3' => '武大郎',
	'setAward_1' => '您成功邀請好友',
	'setAward_2' => '獎勵銀兩5。',
	'setAward_3' => '好友給您送禮啦',
	'setAward_4' => ' 給您送來了1點軍糧! 禮尚往來才是美德,給人家回個禮吧!',
	'createRole_1' => '角色資訊不合法',
	'createRole_2' => '角色名非法',
	'createRole_3' => '該用戶已經擁有一個角色',
	'createRole_4' => '角色名稱已經存在',
	'createRole_5' => '角色資訊不合法',
	'createRole_6' => '插入資料失敗',
	'login_1' => '當前伺服器人數已滿，請稍後進入，由此給您帶來的不便之處，敬請諒解，感謝您對《Q將水滸》的支持與厚愛！',
	'login_2' => 'QQ新人',
	'login_3' => '銅錢',
	'login_4' => '藍將卡',
	'login_5' => '1張',
	'lpm_1' => '此禮包碼無效！',
	'lpm_2' => '該禮包碼類型不存在！',
	'lpm_3' => '你已經領取過一次該禮包！'
);
