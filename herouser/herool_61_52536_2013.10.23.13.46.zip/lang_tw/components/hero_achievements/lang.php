<?php
$cj_lang['hqcjxlfx_1'] = '成就資訊有誤！'; 
$cj_lang['hqcjxlfx_2'] = '該成就無法分享！'; 
$cj_lang['hqcjxlfx_3'] = '請到探報中領取獎勵！背包已滿，請先整理或擴容！'; 
$cj_lang['hqcjxlfx_4'] = '成就分享獎勵';
$cj_lang['hqcjxlfx_5'] = '成就分享失敗';
$cj_lang['hqcjxlfx_6'] = '太厲害了！我完成了成就';
$cj_lang['hqcjxlfx_7'] = '立即加入【逆轉風雲】和我一起打造屬於我們的水滸世界！';