<?php
$_g_lang['hd']['p_inf_err'] = '玩家資訊錯誤';
$_g_lang['hd']['a_inf_err'] = '活動資訊錯誤';
$_g_lang['hd']['ex_inf_err'] = '兌換資訊錯誤';
$_g_lang['hd']['no_good'] = '該活動沒有可領取的獎品';

$_g_lang['hd']['time_limit'] = '活動未到領獎時間';
$_g_lang['hd']['a_deny'] = '請求的是已封禁活動';
$_g_lang['hd']['good_err'] = '獎品數據有誤！';

$_g_lang['hd']['ex_time_limit'] = '未到兌換時間';
$_g_lang['hd']['exc_count_limit'] = '兌換次數已達上限';

$_g_lang['hd']['lqpflb'] = '感謝評分，請領取評分禮包大獎！';
