<?php
static $rw_lang = array(
	'rw_getRWInfo_1' => '隨機技能書',
	'rw_getRWInfo_2' => '天',
	'rw_getRWInfo_3' => '銀票',
	'rw_getRWInfo_4' => '銅錢',
	'rw_getRWInfo_5' => '元寶',
	'rw_getRWInfo_21' => '未找到任務資訊',
	'rw_getRWList_1' => '沒有任務！',
	'rw_processAward_1' => '背包格數不夠用'
);

$rw_lang['rw_processAward_1'] = "不能領取！\n背包已滿，請先整理或擴容！";
$rw_lang['sxrcrw_1'] = "您也忒勤快了吧！今天任務都做完了！";
$rw_lang['hqhyjl_1'] = "您的活躍度不夠，不能領取該獎勵！";
$rw_lang['hqhyjl_2'] = "您已經領取過該獎勵，不能再次領取";
$rw_lang['hqhyjl_3'] = "聲望";
$rw_lang['rw_processAward_2'] = "不能開啟！\n背包已滿，請先整理或擴容！";
