<?php
class model extends heroCommond {    
    function test() {
    	echo 'hello';
    }
    
    function load($model,$method,$info) {
    	
    }
}
?>