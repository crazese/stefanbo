<?php
$cj_lang['hqcjxlfx_1'] = '成就信息有误！'; 
$cj_lang['hqcjxlfx_2'] = '该成就无法分享！'; 
$cj_lang['hqcjxlfx_3'] = '请到探报中领取奖励！背包已满，请先整理或扩容！'; 
$cj_lang['hqcjxlfx_4'] = '成就分享奖励';
$cj_lang['hqcjxlfx_5'] = '成就分享失败';
$cj_lang['hqcjxlfx_6'] = '太厲害了！我完成了成就';
$cj_lang['hqcjxlfx_7'] = '立即加入【逆轉風雲】和我一起打造屬於我們的水滸世界！';