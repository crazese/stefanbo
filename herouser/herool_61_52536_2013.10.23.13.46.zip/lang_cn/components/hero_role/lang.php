<?php
static $role_lang = array(
	'saveRoleInfo_1' => '朱贵',
	'saveRoleInfo_2' => '张顺',
	'saveRoleInfo_3' => '武大郎',
	'setAward_1' => '您成功邀请好友',
	'setAward_2' => '奖励银两5。',
	'setAward_3' => '好友给您送礼啦',
	'setAward_4' => ' 给您送来了1点军粮! 礼尚往来才是美德,给人家回个礼吧!',
	'createRole_1' => '角色信息不合法',
	'createRole_2' => '角色名非法',
	'createRole_3' => '该用户已经拥有一个角色',
	'createRole_4' => '角色名称已经存在',
	'createRole_5' => '角色信息不合法',
	'createRole_6' => '插入数据失败',
	'login_1' => '当前服务器人数已满，请稍后进入，由此给您带来的不便之处，敬请谅解，感谢您对《Q将水浒》的支持与厚爱！',
	'login_2' => 'QQ新人',
	'login_3' => '铜钱',
	'login_4' => '蓝将卡',
	'login_5' => '1张',
	'lpm_1' => '此礼包码无效！',
	'lpm_2' => '该礼包码类型不存在！',
	'lpm_3' => '你已经领取过一次该礼包！'
);
