<?php
$_g_lang['hd']['p_inf_err'] = '玩家信息错误';
$_g_lang['hd']['a_inf_err'] = '活动信息错误';
$_g_lang['hd']['ex_inf_err'] = '兑换信息错误';
$_g_lang['hd']['no_good'] = '该活动没有可领取的奖品';

$_g_lang['hd']['time_limit'] = '活动未到领奖时间';
$_g_lang['hd']['a_deny'] = '请求的是已封禁活动';
$_g_lang['hd']['good_err'] = '奖品数据有误！';

$_g_lang['hd']['ex_time_limit'] = '未到兑换时间';
$_g_lang['hd']['exc_count_limit'] = '兑换次数已达上限';

$_g_lang['hd']['lqpflb'] = '感谢评分，请领取评分礼包大奖！';