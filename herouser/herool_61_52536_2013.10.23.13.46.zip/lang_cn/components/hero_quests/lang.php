<?php
static $rw_lang = array(
	'rw_getRWInfo_1' => '随机技能书',
	'rw_getRWInfo_2' => '天',
	'rw_getRWInfo_3' => '银票',
	'rw_getRWInfo_4' => '铜钱',
	'rw_getRWInfo_5' => '元宝',
	'rw_getRWInfo_21' => '未找到任务信息',
	'rw_getRWList_1' => '没有任务！',
	'rw_processAward_1' => '背包格数不够用'
);

$rw_lang['rw_processAward_1'] = "不能领取！\n背包已满，请先整理或扩容！";
$rw_lang['sxrcrw_1'] = "您也忒勤快了吧！今天任务都做完了！";
$rw_lang['hqhyjl_1'] = "您的活跃度不够，不能领取该奖励！";
$rw_lang['hqhyjl_2'] = "您已经领取过该奖励，不能再次领取";
$rw_lang['hqhyjl_3'] = "声望";
$rw_lang['rw_processAward_2'] = "不能开启！\n背包已满，请先整理或扩容！";
