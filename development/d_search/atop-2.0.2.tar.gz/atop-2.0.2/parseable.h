int 	parsedef(char *);
char	parseout(time_t, int, struct sstat *, struct tstat *, struct tstat **,
                 int, int, int, int, int, int, int, int,
	         int, unsigned int, char);
