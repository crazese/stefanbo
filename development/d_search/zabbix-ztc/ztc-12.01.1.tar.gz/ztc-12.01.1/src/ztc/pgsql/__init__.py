#!/usr/bin/env python
"""
ZTC pgsql package

Used in PostgreSQL-related templates

Copyright (c) 2010-2011 Vladimir Rusinov <vladimir@greenmice.info>
"""
