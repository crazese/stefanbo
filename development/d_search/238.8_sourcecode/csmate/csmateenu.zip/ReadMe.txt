* Introduction
CSMate is a free tool which enables you to say to others using your native 
language other than English while playing Counter-Strike 1.6 and 
Condition Zero.

* Installation
Unzip CSMateEnu.zip to any folder, for example, C:\CSMate. Double click 
CSMate.exe to execute. When the first time you run this program, it will prompt 
you to enter the path of the executable file of Counter-Strike (the file name 
must be hl.exe, cstrike.exe or czero.exe). If you do not know the path, please 
right- click the shortcut of Counter-Strike, then select "Properties" from the 
popup menu, then you can find the path in the properties 
window.

* Using
Launch this program, then start Counter-Strike. When you are playing, you can 
press 'Y' or 'U' to open the input window. Use Enter to send and use Esc 
to cancel.

* System Requirements
Windows 98/Me/2000/XP/2003
Counter-Strike 1.6 or Condition Zero

* End
If you have any problem, please mail to me: ch@sothink.com


SourceTec Software Co., LTD
http://www.sothink.com
