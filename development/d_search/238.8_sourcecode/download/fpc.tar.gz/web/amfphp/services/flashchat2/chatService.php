<?php
 class chatService{
	function getConn()
	{
		$db = mysql_connect("{SERVER}", "{USER}","{PSWD}");
		if (!$db)
			return mysql_error();
		$db = mysql_select_db("{DATABASE}");
		if (!$db)
			return mysql_error();
		
		return null;
	}
	
	/**
	 * construtor method.
	 *  
	 * create methodTable and connect to mysql
	 */
	function chatService(){
		$this->methodTable = array(
			"getAllRoomCfg" => array(
				"description" => "Get all room data",
				"access" => "remote"),
			"saveRoomCfg" => array(
				"description" => "Save room data",
				"access" => "remote"),
			"deleteRoomCfg" => array(
				"description" => "Delete a room",
				"access" => "remote"),	
			"login" => array(
				"description" => "Login verify",
				"access" => "remote"),	
			"register" => array(
				"description" => "Register a new user",
				"access" => "remote"),	
			"loadUserData" => array(
				"description" => "Load user data",
				"access" => "remote"),	
			"saveUserData" => array(
				"description" => "Save user data",
				"access" => "remote"),	
			"deleteUserData" => array(
				"description" => "Delete a user",
				"access" => "remote"),	
			"getAccountList" => array(
				"description" => "Get all user data",
				"access" => "remote"),	
			"addTextChatHistory" => array(
				"description" => "Save chat record",
				"access" => "remote"),	
			"getTextChatHistoryList" => array(
				"description" => "Search chat history record",
				"access" => "remote"),	
			"deleteTextChatHistory" => array(
				"description" => "Clear all chat history record in the room",
				"access" => "remote"),	
		);
	}

	function checkKeys($o, $keys)
	{
		foreach($keys as $value)
		{
			if (!array_key_exists($value, $o))
				return false;
		}
		return true;
	}
	
	function IsNullOrEmpty($str)
	{
		if ($str == null || $str == "")
			return true;
		return false;
	}
	
	function getAllRoomCfg()
	{
		$r = $this->getConn();
		if ($r != null)
		{
			return array("succeed" => false, "info" => $r);
		}
		//-----------------
		$sql = "SELECT * FROM fpchat_Rooms ORDER BY name";
		$result = mysql_query($sql);
		if (!$result)
		{
			return array("succeed" => false, "info" => "RET_ERROR_007");
		}
		$arrays = array();
		while ( $rows = mysql_fetch_assoc($result))
		{
			$arrays[] = $rows;
		}
		
		mysql_free_result($result);
		
		return array("succeed" => true, "data" => $arrays);
	}
	
	function saveRoomCfg($room)
	{
		$r = $this->getConn();
		if ($r != null)
		{
			return array("succeed" => false, "info" => $r);
		}
		//-----------------
		if (!$this->checkKeys($room,array("rid","name","icon","description","welcome",
                                    "administrators","password","enableInList","enableJoin",
                                    "enableGuest","enableDeskLogin","enableRename","maxOnline",
                                    "dumbTime","blockNames","kickTime","blockIps","kickIpTime",
                                    "enterRoomSound","quitRoomSound","messageSound","noticeSound","pluginCfgs")))
		{
			return array("succeed" => false, "info" => "RET_ERROR_001");
		}
		
		$rid = $room[rid];
		$name = addslashes($room[name]);
		$icon = addslashes($room[icon]);
		$description = addslashes($room[description]);
		$welcome = addslashes($room[welcome]);
		$administrators = addslashes($room[administrators]);
		$password = addslashes($room[password]);
		$enableInList = $room[enableInList];
		$enableJoin = $room[enableJoin];
		$enableGuest = $room[enableGuest];
		$enableDeskLogin = $room[enableDeskLogin];
		$enableRename = $room[enableRename];
		$maxOnline = $room[maxOnline];
		$dumbTime = $room[dumbTime];
		$blockNames = addslashes($room[blockNames]);
		$kickTime = $room[kickTime];
		$blockIps = addslashes($room[blockIps]);
		$kickIpTime = $room[kickIpTime];
		$enterRoomSound = $room[enterRoomSound];
		$quitRoomSound = $room[quitRoomSound];
		$messageSound = $room[messageSound];
		$noticeSound = $room[noticeSound];
		$pluginCfgs = addslashes($room[pluginCfgs]);

		$enableInList = ($enableInList == null) ? "null" : $enableInList;
		$enableJoin = ($enableJoin == null) ? "null" : $enableJoin;
		$enableGuest = ($enableGuest == null) ? "null" : $enableGuest;
		$enableDeskLogin = ($enableDeskLogin == null) ? "null" : $enableDeskLogin;
		$enableRename = ($enableRename == null) ? "null" : $enableRename;
		$maxOnline = ($maxOnline == null) ? "null" : $maxOnline;
		$dumbTime = ($dumbTime == null) ? "null" : $dumbTime;
		$kickTime = ($kickTime == null) ? "null" : $kickTime;
		$kickIpTime = ($kickIpTime == null) ? "null" : $kickIpTime;
		$enterRoomSound = ($enterRoomSound == null) ? "null" : $enterRoomSound;
		$quitRoomSound = ($quitRoomSound == null) ? "null" : $quitRoomSound;
		$messageSound = ($messageSound == null) ? "null" : $messageSound;
		$noticeSound = ($noticeSound == null) ? "null" : $noticeSound;
		
		$sql = "SELECT name FROM fpchat_Rooms WHERE (rid = $room[rid])";
		$result = mysql_query($sql);
		if (!$result)
		{
			return array("succeed" => false, "info" => "RET_ERROR_007");
		}
		
		$rownum = mysql_num_rows($result);
		
		if ($rownum > 0)
		{
			$sql = "UPDATE fpchat_Rooms SET name = '$name', icon = '$icon', description = '$description', ";
			$sql .= "welcome = '$welcome', administrators = '$administrators', password = '$password', ";
			$sql .= "enableInList = $enableInList, enableJoin = $enableJoin, enableGuest = $enableGuest, ";
			$sql .= "enableDeskLogin = $enableDeskLogin, enableRename = $enableRename, ";
			$sql .= "maxOnline = $maxOnline, dumbTime = $dumbTime, blockNames = '$blockNames', ";
			$sql .= "kickTime = $kickTime, blockIps = '$blockIps', kickIpTime = $kickIpTime, ";
			$sql .= "enterRoomSound = $enterRoomSound, quitRoomSound = $quitRoomSound, ";
			$sql .= "messageSound = $messageSound, noticeSound = $noticeSound, pluginCfgs = '$pluginCfgs' ";
			$sql .= "WHERE (rid = $rid)";
		}else{
			$sql = "INSERT INTO fpchat_Rooms (rid, name, icon, description, welcome, administrators, password, enableInList, ";
			$sql .= "enableJoin, enableGuest, enableDeskLogin, enableRename, maxOnline, dumbTime, blockNames, kickTime, ";
			$sql .= "blockIps, kickIpTime, enterRoomSound, quitRoomSound, messageSound, noticeSound, pluginCfgs) ";
			$sql .= "VALUES ($rid, '$name', '$icon', '$description', '$welcome', ";
			$sql .= "'$administrators', '$password', $enableInList, $enableJoin, $enableGuest, ";
			$sql .= "$enableDeskLogin, $enableRename, $maxOnline, $dumbTime, '$blockNames', ";
			$sql .= "$kickTime, '$blockIps', $kickIpTime, $enterRoomSound, $quitRoomSound, ";
			$sql .= "$messageSound, $noticeSound, '$pluginCfgs')";
		}
		
		$result = mysql_query($sql);
		if ($result)
		{
			return array("succeed" => true);
		}else{
			return array("succeed" => false, "info" => "RET_ERROR_005");
		}
	}
	
	
	function deleteRoomCfg($roomID)
	{
		$r = $this->getConn();
		if ($r != null)
		{
			return array("succeed" => false, "info" => $r);
		}
		//-----------------
		$sql = "DELETE FROM fpchat_Rooms WHERE (rid = $roomID)";
		$result = mysql_query($sql);
		if ($result)
		{
			deleteTextChatHistory($roomID);
			return array("succeed" => true);
		}else{
			return array("succeed" => false, "info" => "RET_ERROR_005");
		}		
	}
	
	
	function login($passObj)
	{
		$r = $this->getConn();
		if ($r != null)
		{
			return array("succeed" => false, "info" => $r);
		}
		//-----------------
		if (!$this->checkKeys($passObj,array("type","name","password")))
		{
			return array("succeed" => false, "info" => "RET_ERROR_001");
		}
		
		$type = strtolower($passObj[type]);
		$name = strtolower(addslashes($passObj[name]));
		$password = strtolower(addslashes($passObj[password]));
		
		$sql = "SELECT * FROM fpchat_Users WHERE (name = '$name')";
		$result = mysql_query($sql);
		if (!$result)
		{
			return array("succeed" => false, "info" => "RET_ERROR_007");
		}
		
		$rownum = mysql_num_rows($result);
		
		$b = ($rownum > 0);
		
		
		if ($type == "guest")
		{
			if ($b)
			{
				return array("succeed" => false, "info" => "RES_ERROR_008");
			}else{
				return array("succeed" => true);
			}
		}else{
			if ($b)
			{
				$userinfo = mysql_fetch_assoc($result);
				if ($password == $userinfo[password])
				{
					$data[name] = $userinfo[name];
					$data[email] = $userinfo[email];
					$data[sex] = $userinfo[sex];
					$data[avatar] = $userinfo[avatar];
					$data[level] = $userinfo[level];
					$data[friendList] = $userinfo[friendList];
					$data[blockList] = $userinfo[blockList];
					
					return array("succeed" => true, "data" => $data);
				}else{
					return array("succeed" => false, "info" => "RES_ERROR_010");
				}
			}else{
				return array("succeed" => false, "info" => "RES_ERROR_009");
			}
		}
	} 
	
	function register($passObj)
	{
		$r = $this->getConn();
		if ($r != null)
		{
			return array("succeed" => false, "info" => $r);
		}
		//-----------------
		if (!$this->checkKeys($passObj,array("name", "password", "email", "sex", "avatar", "level")))
		{
			return array("succeed" => false, "info" => "RET_ERROR_001");
		}
		
		$name = addslashes($passObj[name]);
		$password = addslashes($passObj[password]);
		$email = addslashes($passObj[email]);
		$sex = addslashes($passObj[sex]);
		$avatar = addslashes($passObj[avatar]);
		$level = $passObj[level];
		
		$sql = "SELECT id FROM fpchat_Users WHERE (name = '$name')";
		$result = mysql_query($sql);
		if (!$result)
		{
			return array("succeed" => false, "info" => "RET_ERROR_007");
		}
		
		$rownum = mysql_num_rows($result);
		
		if ($rownum != 0)
		{
			return array("succeed" => false, "info" => "RES_ERROR_011");
		}
		
		$sql = "INSERT INTO fpchat_Users (name, `password`, email, sex, avatar, `level`) ";
		$sql .= "VALUES ('$name','$password','$email','$sex','$avatar',$level)";
		$result = mysql_query($sql);
		if ($result)
		{
			return array("succeed" => true);
		}else{
			return array("succeed" => false, "info" => "RET_ERROR_005");
		}
	}
	
	function loadUserData($Username)
	{
		if ($this->IsNullOrEmpty($Username))
		{
			return array("succeed" => false, "info" => "RET_ERROR_001");
		}
		$r = $this->getConn();
		if ($r != null)
		{
			return array("succeed" => false, "info" => $r);
		}
		//-----------------
		$Username = addslashes($Username);
		$sql = "SELECT `password`, email, sex, avatar, `level`, friendList, blockList FROM fpchat_Users WHERE (name = '$Username')";
		$result = mysql_query($sql);
		if (!$result)
		{
			return array("succeed" => false, "info" => "RET_ERROR_007");
		}
		$rownum = mysql_num_rows($result);
		
		if ($rownum > 0)
		{
			$userinfo = mysql_fetch_assoc($result);
			$data[password] = $userinfo[password];
			$data[email] = $userinfo[email];
			$data[sex] = $userinfo[sex];
			$data[avatar] = $userinfo[avatar];
			$data[level] = $userinfo[level];
			$data[friendList] = $userinfo[friendList];
			$data[blockList] = $userinfo[blockList];
			return array("succeed" => true, "data" => $data);
		}else{
			return array("succeed" => false, "info" => "RET_ERROR_003");
		}
	}
	
	function saveUserData($User)
	{
		$r = $this->getConn();
		if ($r != null)
		{
			return array("succeed" => false, "info" => $r);
		}
		//-----------------
		if (!$this->checkKeys($User,array("name", "password", "email", "sex", "avatar", "level", "friendList", "blockList")))
		{
			return array("succeed" => false, "info" => "RET_ERROR_001");
		}
		
		$name = addslashes($User[name]);
		$password = addslashes($User[password]);
		$email = addslashes($User[email]);
		$sex = addslashes($User[sex]);
		$avatar = addslashes($User[avatar]);
		$level = $User[level];
		$friendList = addslashes($User[firendList]);
		$blockList = addslashes($User[blockList]);
		
		$sql = "SELECT id FROM fpchat_Users WHERE (name = '$name')";
		$result = mysql_query($sql);
		if (!$result)
		{
			return array("succeed" => false, "info" => "RET_ERROR_007");
		}
		$rownum = mysql_num_rows($result);
		
		if ($rownum > 0)
		{
			$sql = "UPDATE fpchat_Users SET `password` = '$password', email = '$email', sex = '$sex', ";
			$sql .= "avatar = '$avatar', `level` = '$level', friendList = '$friendList', ";
			$sql .= "blockList = '$blockList' WHERE (name = '$name')";
		}else{
			$sql = "INSERT INTO fpchat_Users (name, `password`, email, sex, avatar, `level`, friendList, blockList) ";
			$sql .= "VALUES ('$name','$password','$email','$sex','$avatar',$level,'$friendList','$blockList')";
		}
		$result = mysql_query($sql);
		if ($result)
		{
			return array("succeed" => true);
		}else{
			return array("succeed" => false, "info" => "RET_ERROR_005");
		}
	}
	
	function deleteUserData($username)
	{
		$r = $this->getConn();
		if ($r != null)
		{
			return array("succeed" => false, "info" => $r);
		}
		//-----------------
		if ($this->IsNullOrEmpty($username))
		{
			return array("succeed" => false, "info" => "RET_ERROR_001");
		}
		
		$username = addslashes($username);
		$sql = "DELETE FROM fpchat_Users WHERE (name = '$username')";
		$result = mysql_query($sql);
		if ($result)
		{
			return array("succeed" => true);
		}else{
			return array("succeed" => false, "info" => "RET_ERROR_003");
		}
	}
	
	function getAccountList($pageSize, $pageIndex, $keyword)
	{
		$r = $this->getConn();
		if ($r != null)
		{
			return array("succeed" => false, "info" => $r);
		}
		//-----------------
		$b = $this->IsNullOrEmpty($keyword);

		$keyword = addslashes($keyword);
		
		$sql = "SELECT COUNT(*) AS C FROM fpchat_Users";
		if (!$b)
		{
			$sql .= " WHERE (name LIKE '%$keyword%')";
		}
		$result = mysql_query($sql);
		if (!$result)
		{
			return array("succeed" => false, "info" => "RET_ERROR_007");
		}
		$temp = mysql_fetch_assoc($result);
		$sum = $temp[C];
		if ($sum == 0)
		{

			$h = array("PageIndex" => 0, "PageTotal" => 0);
			return array("succeed" => true, "info" => $h, "data" => null);
		}
		$pageCount = floor(($sum + $pageSize - 1) / $pageSize);
		
		if ($pageIndex > $pageCount)
		{
			$pageIndex = $pageCount;
		}elseif($pageIndex < 1)
		{
			$pageIndex = 1;
		}
		$start = $pageSize * ($pageIndex - 1);
		$sql = "SELECT name, `password`, email, sex, avatar, `level`, friendList, blockList FROM fpchat_Users ";
		if (!$b)
		{
			$sql .= "WHERE (name LIKE '%$keyword%') ";
		}
		$sql .= "ORDER BY name";
		$sql .= " Limit $start,$pageSize";
		
		$result = mysql_query($sql);
		if (!$result)
		{
			return array("succeed" => false, "info" => "RET_ERROR_007");
		}
		$arrays = array();
		while ( $rows = mysql_fetch_assoc($result))
		{
			$arrays[] = $rows;
		}

		$h = array("PageIndex" => $pageIndex, "PageTotal" => $pageCount);
		return array("succeed" => true, "info" => $h, "data" => $arrays);
	}
	
	function addTextChatHistory($RoomID, $Msg)
	{
		$r = $this->getConn();
		if ($r != null)
		{
			return array("succeed" => false, "info" => $r);
		}
		//-----------------
		if (!$this->checkKeys($Msg,array("strFromWho", "strFromIP", "strToWho", "strMessage", "strFace",
						"blnPrivate", "strFont", "strSize", "strColor", "blnBold",
						"blnItalics", "blnUnderline", "strTime")))
		{
			return array("succeed" => false, "info" => "RET_ERROR_001");
		}
		
		$sql = "SELECT name FROM fpchat_Rooms WHERE (rid = $RoomID)";
		$result = mysql_query($sql);
		if (!$result)
		{
			return array("succeed" => false, "info" => "RET_ERROR_007");
		}
		$rownum = mysql_num_rows($result);
		if ($rownum == 0)
		{
			return array("succeed" => false, "info" => "RET_ERROR_008");
		}	
		
		$strFromWho = addslashes($Msg[strFromWho]);
		$strFromIP = $Msg[strFromIP];
		$strToWho = addslashes($Msg[strToWho]);
		$strMessage = addslashes($Msg[strMessage]);
		$strFace = addslashes($Msg[strFace]);
		$blnPrivate = $Msg[blnPrivate] ? 1 : 0;
		$strFont = addslashes($Msg[strFont]);
		$strSize = addslashes($Msg[strSize]);
		$strColor = addslashes($Msg[strColor]);
		$blnBold = $Msg[blnBold] ? 1 : 0;
		$blnItalics = $Msg[blnItalics] ? 1 : 0;
		$blnUnderline = $Msg[blnUnderline] ? 1 : 0;
		$strTime = $Msg[strTime];
		
		$sql = "INSERT INTO fpchat_Logs (roomId, strFromWho, strFromIP, strToWho, strMessage, strFace, blnPrivate, strFont, ";
		$sql .= "strSize, strColor, blnBold, blnItalics, blnUnderline, date) VALUES (";
		$sql .= "$RoomID,'$strFromWho','$strFromIP','$strToWho','$strMessage','$strFace',$blnPrivate,";
		$sql .= "'$strFont','$strSize','$strColor',$blnBold,$blnItalics,$blnUnderline,STR_TO_DATE('$strTime','%m/%d/%Y %T'))";
		$result = mysql_query($sql);
		if ($result)
		{
			return array("succeed" => true);
		}else{
			return array("succeed" => false, "info" => "RET_ERROR_005");
		}		
	}
	
	function getTextChatHistoryList($RoomID, $PageSize, $PageIndex, $Keyword, $KeyType, $TimeFrom, $TimeTo)
	{
		$r = $this->getConn();
		if ($r != null)
		{
			return array("succeed" => false, "info" => $r);
		}
		//-----------------
		$a = $this->IsNullOrEmpty($Keyword);
		$b = $this->IsNullOrEmpty($TimeFrom);
		$c = $this->IsNullOrEmpty($TimeTo);
		
		$Keyword = addslashes($Keyword);
		
		$sql = "SELECT strFromWho, strFromIP, strToWho, strMessage, blnPrivate, DATE_FORMAT(`date`,'%m/%d/%Y %T') as strTime ";
		$sql .= "FROM fpchat_Logs ";
		
		$sumsql = "SELECT COUNT(*) AS C FROM fpchat_Logs ";
		
		$cond = "WHERE (roomId = $RoomID) ";
		
		if (!$a)
		{
			switch ($KeyType)
			{
				case 0:
					$cond .= "AND (strMessage LIKE '%$Keyword%') ";
					break;
				case 1:
					$cond .= "AND (strFromWho LIKE '%$Keyword%') ";
					break;
				case 2:
					$cond .= "AND (strToWho LIKE '%$Keyword%') ";
					break;
			}
		}
		if (!$b)
		{
			$cond .= "AND (`date` >= STR_TO_DATE('$TimeFrom','%m/%d/%Y %T')) ";
		}
		if (!$c)
		{
			$cond .= "AND (`date` <= STR_TO_DATE('$TimeTo','%m/%d/%Y %T')) ";
		}
		$cond .= "ORDER BY `date` DESC ";

		$result = mysql_query($sumsql . $cond);
		if (!$result)
		{
			return array("succeed" => false, "info" => "RET_ERROR_007");
		}
		$temp = mysql_fetch_assoc($result);
		$sum = $temp[C];
		if ($sum == 0)
		{

			$h = array("PageIndex" => 0, "PageTotal" => 0);
			return array("succeed" => true, "info" => $h, "data" => null);
		}
		$pageCount = floor(($sum + $PageSize - 1) / $PageSize);
		
		if ($PageIndex > $pageCount)
		{
			$PageIndex = $pageCount;
		}elseif($PageIndex < 1)
		{
			$PageIndex = 1;
		}
		$start = $PageSize * ($PageIndex - 1);
		$cond .= "Limit $start,$PageSize";
		
		$result = mysql_query($sql . $cond);
		if (!$result)
		{
			return array("succeed" => false, "info" => "RET_ERROR_007");
		}
		$arrays = array();
		while ($row = mysql_fetch_assoc($result))
		{
			$arrays[] = $row;
		}
		$h = array("PageIndex" => $PageIndex, "PageTotal" => $pageCount);
		return array("succeed" => true, "info" => $h, "data" => $arrays);
	}
	
	function deleteTextChatHistory($RoomID)
	{
		$r = $this->getConn();
		if ($r != null)
		{
			return array("succeed" => false, "info" => $r);
		}
		//-----------------
		$sql = "DELETE FROM fpchat_Logs WHERE (roomId = $RoomID)";
		$result = mysql_query($sql);
		if ($result)
		{
			return array("succeed" => true);
		}else{
			return array("succeed" => false, "info" => "RET_ERROR_007");
		}
		
	}
}

?>
